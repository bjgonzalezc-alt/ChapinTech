<?php

require_once '../Conexion/conexion.php';

header("Content-Type: application/json; charset=utf-8");
if($_SERVER['REQUEST_METHOD'] === 'POST'){

    $id_ticket = $_POST['id_ticket'] ?? 0;

    if(!$id_ticket){

        echo json_encode([
            "success" => false,
            "message" => "Ticket inválido"
        ]);

        exit;
    }

    // Primero buscamos el estado actual del ticket.
    // Esto evita cancelar tickets que ya están en reparación, resueltos o cancelados.
    $sqlBuscar = "SELECT estado FROM ticket WHERE id_ticket = ? LIMIT 1";

    $stmtBuscar = $conexion->prepare($sqlBuscar);

    $stmtBuscar->bind_param("i", $id_ticket);

    $stmtBuscar->execute();

    $resultadoBuscar = $stmtBuscar->get_result();

    if($resultadoBuscar->num_rows === 0){

        echo json_encode([
            "success" => false,
            "message" => "Ticket no encontrado"
        ]);

        exit;
    }

    $ticket = $resultadoBuscar->fetch_assoc();

    $estadoActual = $ticket["estado"];

    // Si el técnico ya está trabajando, ya no se puede cancelar.
   if(
        $estadoActual === "en_proceso" ||
        $estadoActual === "finalizado_pendiente_pago" ||
        $estadoActual === "cerrado" ||
        $estadoActual === "cancelado"
    ){
        echo json_encode([
            "success" => false,
            "message" => "Este ticket ya no se puede cancelar porque ya está en una etapa avanzada o concluida."
        ]);
        exit;
    }

    // Si todavía se puede cancelar, actualizamos el estado.
    $sql = "UPDATE ticket
            SET estado = 'cancelado'
            WHERE id_ticket = ?";

    $stmt = $conexion->prepare($sql);

    $stmt->bind_param("i", $id_ticket);

    if($stmt->execute()){

        echo json_encode([
            "success" => true
        ]);

    }else{

        echo json_encode([
            "success" => false,
            "message" => "No se pudo cancelar"
        ]);

    }

    exit;
}
// Obtener código enviado desde JavaScript
$codigo = $_GET['codigo'] ?? '';

// Quita espacios
$codigo = trim($codigo);

// Convierte CT-0001 en 0001
$codigo = strtoupper($codigo);
$codigo = str_replace("CT-", "", $codigo);

// Convierte 0001 en 1
$id_ticket = intval($codigo);

if(empty($codigo)){
    echo json_encode([
        "success" => false,
        "message" => "Código vacío"
    ]);
    exit;
}

// Buscar ticket
$sql = "SELECT * FROM ticket WHERE id_ticket = ?";

$stmt = $conexion->prepare($sql);

$stmt->bind_param("i", $id_ticket);

$stmt->execute();

$resultado = $stmt->get_result();

if($resultado->num_rows > 0){

    $ticket = $resultado->fetch_assoc();

    echo json_encode([
        "success" => true,
        "ticket" => $ticket
    ]);

}else{

    echo json_encode([
        "success" => false,
        "message" => "Ticket no encontrado"
    ]);

}

?>