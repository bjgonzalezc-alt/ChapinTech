document.addEventListener('DOMContentLoaded', () => {
  const menuButton = document.querySelector('.support-menu-btn');
  const navLinks = document.querySelector('.support-shell .nav-links');
  const ticketSearchForm = document.querySelector('.ticket-search-form');
  const ticketResult = document.getElementById('ticketResult');
  const roleButtons = document.querySelectorAll('.role-chip[data-role]');
  const rolePanels = document.querySelectorAll('[data-role-panel]');
  const clientToggleButtons = document.querySelectorAll('.client-toggle-btn[data-client-panel]');
  const clientContents = document.querySelectorAll('[data-client-content]');
  const statusSteps = ['Recibido', 'Asignado', 'Tecnico en Ruta', 'Diagnostico', 'En Reparacion', 'Finalizado'];
  const technicianModal = document.getElementById('technicianModal');
  let activeAssignButton = null;

  const demoTickets = [
    {
      code: 'CT-1024',
      contact: 'carlos@email.com',
      client: 'Carlos Mendez',
      service: 'Reparacion de laptop',
      status: 'En Reparacion',
      technician: 'Anna',
      priority: 'Alta',
      steps: ['Recibido', 'Asignado', 'Tecnico en Ruta', 'Diagnostico', 'En Reparacion']
    },
    {
      code: 'CT-1025',
      contact: '+50248882299',
      client: 'Maria Lopez',
      service: 'Soporte de impresora',
      status: 'Tecnico en ruta',
      technician: 'Kevin',
      priority: 'Media',
      steps: ['Recibido', 'Asignado', 'Tecnico en Ruta']
    }
  ];

  // ========================================
  // SELECT DE SERVICIOS CON IMAGEN Y PRECIO
  // ========================================
  const servicioSelect = document.getElementById("servicio");
  const servicePreviewBg = document.getElementById("servicePreviewBg");
  const serviceTitle = document.getElementById("serviceTitle");
  const servicePrice = document.getElementById("servicePrice");
  const serviceDesc = document.getElementById("serviceDesc");
  const serviceTags = document.getElementById("serviceTags");

  function actualizarVistaServicio() {
    if (!servicioSelect || !servicePreviewBg || !serviceTitle || !servicePrice || !serviceDesc || !serviceTags) return;

    const selectedOption = servicioSelect.options[servicioSelect.selectedIndex];
    const title = selectedOption.dataset.title || "Servicio";
    const price = selectedOption.dataset.price || "Q0";
    const desc = selectedOption.dataset.desc || "Selecciona un servicio para ver más información.";
    const bg = selectedOption.dataset.bg || "";
    const tags = selectedOption.dataset.tags ? selectedOption.dataset.tags.split(",") : [];

    serviceTitle.textContent = title;
    servicePrice.textContent = price;
    serviceDesc.textContent = desc;

    if (bg) {
      servicePreviewBg.style.backgroundImage = `url('${bg}')`;
    }

    serviceTags.innerHTML = "";
    tags.forEach((tag) => {
      const span = document.createElement("span");
      span.textContent = tag.trim();
      serviceTags.appendChild(span);
    });
  }

  if (servicioSelect) {
    servicioSelect.addEventListener("change", actualizarVistaServicio);
    actualizarVistaServicio();
  }

  // ========================================
  // CREAR TICKET REAL EN MYSQL (FLUJO MODAL)
  // ========================================
  const crearTicketBtn = document.getElementById("crearTicketBtn");
  const ticketCreado = document.getElementById("ticketCreado");
  const descripcionProblema = document.getElementById("descripcionProblema");
  
  // Elementos del Modal de Pago
  const paymentModal = document.getElementById('paymentModalOverlay');
  const closePaymentModal = document.getElementById('closePaymentModal');
  const confirmPaymentBtn = document.getElementById('confirmPaymentBtn');
  
  const summaryService = document.getElementById('summaryService');
  const summaryDesc = document.getElementById('summaryDesc');
  const summaryPrice = document.getElementById('summaryPrice');
  
  const btnEfectivo = document.getElementById('btnEfectivo');
  const btnTarjeta = document.getElementById('btnTarjeta');
  const cardForm = document.getElementById('cardForm');
  // Usamos getElementsByName por seguridad
  const getRadiosPago = () => document.querySelectorAll('input[name="metodo_pago"]');

  function limpiarTexto(texto) {
    const div = document.createElement("div");
    div.textContent = texto;
    return div.innerHTML;
  }

  if (crearTicketBtn && ticketCreado && servicioSelect && paymentModal) {
    
    // 1. Botón inicial: Validar formulario y abrir Modal
    crearTicketBtn.addEventListener("click", () => {
      const descripcion = descripcionProblema ? descripcionProblema.value.trim() : "";

      if (!descripcion) {
        ticketCreado.classList.add("show");
        ticketCreado.innerHTML = `
          <h4>Falta la descripción</h4>
          <p>Describe brevemente el problema para poder continuar.</p>
        `;
        return;
      }
      
      ticketCreado.classList.remove("show"); // Ocultar errores previos

      const selectedOption = servicioSelect.options[servicioSelect.selectedIndex];
      
      // Llenar el resumen del Modal
      summaryService.textContent = selectedOption.dataset.title;
      summaryPrice.textContent = selectedOption.dataset.price;
      
      let descShort = descripcion.length > 35 ? descripcion.substring(0, 35) + '...' : descripcion;
      summaryDesc.textContent = descShort;

      // Abrir Modal
      paymentModal.classList.remove('hidden');
    });

    // 2. Cerrar Modal
    closePaymentModal.addEventListener('click', () => {
      paymentModal.classList.add('hidden');
    });

    // 3. Alternar Métodos de Pago
    btnEfectivo.addEventListener('click', () => {
      btnEfectivo.classList.add('active');
      btnTarjeta.classList.remove('active');
      getRadiosPago()[0].checked = true; // Selecciona efectivo
      cardForm.classList.add('hidden');
    });

    btnTarjeta.addEventListener('click', () => {
      btnTarjeta.classList.add('active');
      btnEfectivo.classList.remove('active');
      getRadiosPago()[1].checked = true; // Selecciona tarjeta
      cardForm.classList.remove('hidden');
    });

    // Formateo visual de tarjeta (Solo para UI)
    document.getElementById('cardNumber')?.addEventListener('input', function() {
        this.value = this.value.replace(/\D/g, '').replace(/(.{4})/g, '$1 ').trim();
    });
    document.getElementById('cardExpiry')?.addEventListener('input', function() {
        this.value = this.value.replace(/\D/g, '').replace(/^(\d{2})/, '$1/').substring(0, 5);
    });

    // 4. Confirmar Pago y Enviar
    confirmPaymentBtn.addEventListener('click', async () => {
      const radioSeleccionado = document.querySelector('input[name="metodo_pago"]:checked');
      if (!radioSeleccionado) return;

      const metodoSeleccionado = radioSeleccionado.value;

      // Validación simple de tarjeta
      if(metodoSeleccionado === 'tarjeta') {
          const numTar = document.getElementById('cardNumber').value.replace(/\s/g, '');
          const expTar = document.getElementById('cardExpiry').value;
          const cvcTar = document.getElementById('cardCvc').value;
          
          if(numTar.length < 15 || expTar.length < 5 || cvcTar.length < 3) {
              alert("Por favor, completa los datos de la tarjeta correctamente.");
              return;
          }
          confirmPaymentBtn.innerHTML = `<span>Procesando pago... ⏳</span>`;
      } else {
          confirmPaymentBtn.innerHTML = `<span>Generando ticket... ⏳</span>`;
      }

      confirmPaymentBtn.disabled = true;

      // Recolectar datos
      const selectedOption = servicioSelect.options[servicioSelect.selectedIndex];
      const formData = new FormData();
      formData.append("tipo_servicio", selectedOption.dataset.title || "");
      formData.append("descripcion", descripcionProblema.value.trim());
      formData.append("id_tarifa", selectedOption.dataset.tarifaId || "");
      formData.append("metodo_pago", metodoSeleccionado);

      try {
        const response = await fetch("crear_ticket.php", {
          method: "POST",
          body: formData
        });

        const data = await response.json();
        
        if (!data.success) {
          throw new Error(data.message || "No se pudo crear el ticket.");
        }

        const ticket = data.ticket;

        // Ocultar modal y mostrar cuadro verde de éxito
        paymentModal.classList.add('hidden');
        ticketCreado.classList.add("show");
        ticketCreado.innerHTML = `
          <div style="background: rgba(0,255,128,0.1); border: 1px solid #00ff80; padding: 20px; border-radius: 12px; text-align: center;">
            <h4 style="color: #00ff80; margin-bottom: 10px; font-family: 'Orbitron', sans-serif;">¡${metodoSeleccionado === 'tarjeta' ? 'Pago Exitoso y ' : ''}Ticket Creado! ✅</h4>
            <p style="color: white; margin-bottom: 8px;">Código de seguimiento:</p>
            <span style="display: block; font-size: 1.5rem; font-weight: bold; color: #63e6ff; letter-spacing: 2px; margin-bottom: 15px;">${limpiarTexto(ticket.codigo)}</span>
            <p style="color: rgba(255,255,255,0.7); font-size: 0.9rem; margin:0;">Hemos enviado los detalles a tu correo electrónico.</p>
          </div>
        `;

        descripcionProblema.value = "";
        
        // Limpiar tarjeta si se usó
        if (metodoSeleccionado === 'tarjeta') {
          document.getElementById('cardNumber').value = "";
          document.getElementById('cardExpiry').value = "";
          document.getElementById('cardCvc').value = "";
          document.getElementById('cardName').value = "";
        }

      } catch (error) {
        alert("Error: " + error.message);
      } finally {
        confirmPaymentBtn.disabled = false;
        confirmPaymentBtn.innerHTML = `<span>Confirmar y Pagar</span>`;
      }
    });
  }

  // ========================================
  // LÓGICA DE PANELES, BÚSQUEDA Y DEMOS
  // ========================================
  if (!ticketSearchForm || !ticketResult) return;

  function setRoleView(role) {
    roleButtons.forEach((button) => {
      const isActive = button.dataset.role === role;
      button.classList.toggle('active', isActive);
      button.setAttribute('aria-selected', String(isActive));
    });

    rolePanels.forEach((panel) => {
      panel.classList.toggle('is-collapsed', panel.dataset.rolePanel !== role);
    });
  }

  function setClientPanel(panelName) {
    clientToggleButtons.forEach((button) => {
      const isActive = button.dataset.clientPanel === panelName;
      button.classList.toggle('active', isActive);
      button.setAttribute('aria-expanded', String(isActive));
    });

    clientContents.forEach((content) => {
      content.classList.toggle('is-collapsed', content.dataset.clientContent !== panelName);
    });
  }

  function renderStatusBar(activeSteps, size = 'default') {
    const lastActiveIndex = Math.max(...activeSteps.map((step) => statusSteps.indexOf(step)));
    const progress = lastActiveIndex <= 0 ? 0 : (lastActiveIndex / (statusSteps.length - 1)) * 100;
    const sizeClass = size === 'compact' || size === 'client' ? size : '';

    return `
      <div class="status-progress ${sizeClass}">
        <div class="status-track">
          <div class="status-fill" style="width:${progress}%; --progress:${progress}%;"></div>
          ${statusSteps.map((step, index) => {
            const isDone = index <= lastActiveIndex ? 'done' : '';
            const isCurrent = index === lastActiveIndex ? 'current' : '';
            return `
              <div class="status-point ${isDone} ${isCurrent}">
                <span></span>
                <p>${step}</p>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }

  function openTechnicianModal(assignButton) {
    activeAssignButton = assignButton;
    technicianModal.classList.remove('is-collapsed');
    technicianModal.setAttribute('aria-hidden', 'false');
  }

  function closeTechnicianModal() {
    technicianModal.classList.add('is-collapsed');
    technicianModal.setAttribute('aria-hidden', 'true');
    activeAssignButton = null;
  }

  roleButtons.forEach(button => button.addEventListener('click', () => setRoleView(button.dataset.role)));
  clientToggleButtons.forEach(button => button.addEventListener('click', () => setClientPanel(button.dataset.clientPanel)));
  document.querySelectorAll('.assign-tech-btn').forEach(button => button.addEventListener('click', () => openTechnicianModal(button)));
  document.querySelectorAll('[data-close-modal]').forEach(button => button.addEventListener('click', closeTechnicianModal));

  document.querySelectorAll('.technician-option').forEach((button) => {
    button.addEventListener('click', () => {
      if (!activeAssignButton) return;
      activeAssignButton.textContent = button.dataset.technician;
      activeAssignButton.classList.remove('assign-tech-btn');
      activeAssignButton.classList.add('assigned-tech-btn');
      closeTechnicianModal();
    });
  });

  setRoleView('client');
  setClientPanel('search');

  ticketSearchForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const code = ticketSearchForm.querySelector('#ticketCode').value.trim().toUpperCase();
    const ticket = demoTickets.find((item) => item.code === code);

    if (!ticket) {
      ticketResult.classList.remove('is-collapsed');
      ticketResult.innerHTML = `
        <div class="ticket-result-error">
          <span>!</span>
          <h3>Numero incorrecto o inexistente</h3>
          <p>No encontramos un ticket con ese codigo. Verifica el numero e intenta nuevamente.</p>
        </div>
      `;
      return;
    }

    ticketResult.classList.remove('is-collapsed');
    ticketResult.innerHTML = `
      <div class="ticket-result-live">
        <div class="module-heading">
          <div>
            <p>Ticket encontrado</p>
            <h2>${ticket.code}</h2>
          </div>
          <span class="module-badge">${ticket.status}</span>
        </div>
        <div class="ticket-meta-grid">
          <div class="ticket-meta">
            <p>Cliente</p>
            <strong>${ticket.client}</strong>
          </div>
          <div class="ticket-meta">
            <p>Tecnico</p>
            <strong>${ticket.technician}</strong>
          </div>
          <div class="ticket-meta">
            <p>Servicio</p>
            <strong>${ticket.service}</strong>
          </div>
          <div class="ticket-meta">
            <p>Prioridad</p>
            <strong>${ticket.priority}</strong>
          </div>
        </div>
        ${renderStatusBar(ticket.steps, 'client')}
      </div>
    `;
  });

  document.querySelectorAll('.admin-ticket-row[data-steps]').forEach((row) => {
    const activeSteps = row.dataset.steps.split(',').map((step) => step.trim());
    const progressTarget = row.querySelector('.admin-ticket-progress');
    if (progressTarget) progressTarget.innerHTML = renderStatusBar(activeSteps, 'compact');
  });
});
