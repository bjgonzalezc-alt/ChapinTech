<?php
session_start();
if (!isset($_SESSION['nivel_acceso']) || $_SESSION['nivel_acceso'] < 80) {
    header("Location: login.php");
    exit();
}

require_once __DIR__ . '/../../libs/config/database.php';
$conn = AuthDatabase::getInstance();

// ==========================================
// NUEVA FUNCIÓN: Eliminar Ticket vía AJAX
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_ticket') {
    header('Content-Type: application/json');
    try {
        $id_ticket = intval($_POST['id_ticket']);
        // Gracias al ON DELETE CASCADE de tu SQL, esto también borrará historial, pagos, etc.
        $delStmt = $conn->prepare("DELETE FROM ticket WHERE id_ticket = ?");
        $delStmt->execute([$id_ticket]);
        
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit();
}

// Obtener todos los tickets con los datos del cliente unidos
$query = "SELECT t.id_ticket, t.titulo, t.estado, t.prioridad, t.fecha_creacion, 
                 u.nombre AS cliente_nombre, u.email AS cliente_email 
          FROM ticket t 
          JOIN cliente c ON t.id_cliente = c.id_cliente 
          JOIN usuario u ON c.id_usuario = u.id_usuario 
          ORDER BY t.id_ticket DESC";
$stmt = $conn->prepare($query);
$stmt->execute();
$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>ChapinTech | Historial de Tickets</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #020617; color: white; margin: 0; padding: 20px; }
        .container { max-width: 1200px; margin: 20px auto; background: rgba(255,255,255,.03); border: 1px solid rgba(99,230,255,.12); border-radius: 24px; padding: 40px; box-shadow: 0 0 50px rgba(34,211,238,.05); backdrop-filter: blur(18px); }
        .btn-back { display: inline-block; color: #63e6ff; text-decoration: none; font-weight: 600; padding: 8px 16px; border-radius: 8px; background: rgba(99,230,255,.1); border: 1px solid rgba(99,230,255,.2); margin-bottom: 20px; transition: 0.3s; }
        .btn-back:hover { background: rgba(99,230,255,.2); transform: translateX(-5px); }
        .header-panel { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255,255,255,.08); padding-bottom: 20px; margin-bottom: 20px; }
        h2 { font-family: 'Orbitron', sans-serif; color: #63e6ff; margin: 0; }
        
        .toolbar { display: flex; gap: 15px; margin-bottom: 25px; flex-wrap: wrap; }
        .toolbar input, .toolbar select { padding: 12px 18px; border-radius: 12px; background: #07111f; color: white; border: 1px solid rgba(99,230,255,.2); outline: none; font-size: 0.95rem; }
        .toolbar input { flex-grow: 1; min-width: 250px; }
        
        table { width: 100%; border-collapse: collapse; }
        th { font-family: 'Orbitron', sans-serif; color: rgba(255,255,255,.6); text-align: left; padding: 15px; font-size: 0.85rem; border-bottom: 2px solid rgba(255,255,255,.08); user-select: none; }
        th.sortable { cursor: pointer; transition: color 0.2s; }
        th.sortable:hover { color: #63e6ff; }
        .sort-icon { color: #63e6ff; margin-left: 5px; font-size: 0.8rem; }
        td { padding: 15px; border-bottom: 1px solid rgba(255,255,255,.05); font-size: 0.95rem; vertical-align: middle; }
        
        .badge { padding: 6px 12px; border-radius: 999px; font-size: 0.8rem; font-weight: bold; white-space: nowrap; }
        .badge-pendiente { background: rgba(255, 193, 7, 0.2); color: #ffc107; border: 1px solid rgba(255,193,7,.4); }
        .badge-proceso { background: rgba(59, 167, 255, 0.2); color: #3ba7ff; border: 1px solid rgba(59,167,255,.4); }
        .badge-cerrado { background: rgba(0, 255, 128, 0.2); color: #00ff80; border: 1px solid rgba(0,255,128,.4); }
        .badge-reabierto { background: rgba(255, 77, 77, 0.2); color: #ff4d4d; border: 1px solid rgba(255,77,77,.4); } /* Nuevo color para reabiertos */
        .hidden-row { display: none !important; }

        /* Botón de eliminar */
        .btn-delete { background: rgba(255, 77, 77, 0.1); color: #ff4d4d; border: 1px solid rgba(255, 77, 77, 0.3); border-radius: 8px; padding: 8px 12px; cursor: pointer; transition: 0.3s; font-size: 1rem; }
        .btn-delete:hover { background: #ff4d4d; color: white; transform: scale(1.05); box-shadow: 0 0 10px rgba(255,77,77,0.5); }
    </style>
</head>
<body>

<div class="container">
    <a href="../../admin.php" class="btn-back">← Volver al Panel Admin</a>
    
    <div class="header-panel">
        <div>
            <h2>Historial de Tickets</h2>
            <p style="color: rgba(255,255,255,.5); margin: 5px 0 0 0;">Gestión general de incidencias reportadas.</p>
        </div>
    </div>

    <div class="toolbar">
        <input type="text" id="searchInput" placeholder="Buscar por # Ticket, Cliente o Correo...">
        <select id="statusFilter">
            <option value="todos">Todos los Estados</option>
            <option value="activos">Nuevos / Activos (Pendiente, Asignado, Reabierto)</option>
            <option value="proceso">En Proceso (En Camino, Reparando)</option>
            <option value="cerrados">Cerrados / Finalizados / Cancelados</option>
        </select>
    </div>

    <table id="ticketsTable">
        <thead>
            <tr>
                <th class="sortable" data-sort="id"># Ticket <span class="sort-icon">⇅</span></th>
                <th>Asunto</th>
                <th>Cliente / Correo</th>
                <th class="sortable" data-sort="fecha">Fecha Reporte <span class="sort-icon">⇅</span></th>
                <th>Estado</th>
                <th style="text-align: center;">Acciones</th>
            </tr>
        </thead>
        <tbody id="tableBody">
            <?php foreach ($tickets as $t): 
                // CORRECCIÓN: Agrupación estricta basándonos en el ENUM de tu BD
                $estadoFiltro = 'activos'; // Fallback por defecto
                $claseBadge = 'badge-pendiente';
                
                if (in_array($t['estado'], ['pendiente', 'asignado'])) {
                    $estadoFiltro = 'activos';
                    $claseBadge = 'badge-pendiente';
                } elseif (in_array($t['estado'], ['en_camino', 'en_proceso', 'finalizado_pendiente_pago'])) {
                    $estadoFiltro = 'proceso';
                    $claseBadge = 'badge-proceso';
                } elseif (in_array($t['estado'], ['cerrado', 'cancelado'])) {
                    $estadoFiltro = 'cerrados';
                    $claseBadge = 'badge-cerrado';
                } elseif ($t['estado'] === 'reabierto') {
                    $estadoFiltro = 'activos';
                    $claseBadge = 'badge-reabierto';
                }
            ?>
            <tr class="ticket-row" 
                data-id="<?= $t['id_ticket'] ?>" 
                data-fecha="<?= strtotime($t['fecha_creacion']) ?>"
                data-estado="<?= $estadoFiltro ?>"
                data-search="<?= strtolower($t['id_ticket'] . ' ' . $t['cliente_nombre'] . ' ' . $t['cliente_email']) ?>">
                
                <td style="font-family: 'Orbitron', sans-serif; color: #63e6ff;">CT-<?= str_pad($t['id_ticket'], 4, '0', STR_PAD_LEFT) ?></td>
                <td><?= htmlspecialchars($t['titulo']) ?></td>
                <td>
                    <strong><?= htmlspecialchars($t['cliente_nombre']) ?></strong><br>
                    <span style="font-size: 0.8rem; color: rgba(255,255,255,.5);"><?= htmlspecialchars($t['cliente_email']) ?></span>
                </td>
                <td><?= date("d/m/Y H:i", strtotime($t['fecha_creacion'])) ?></td>
                <td><span class="badge <?= $claseBadge ?>"><?= strtoupper(str_replace('_', ' ', $t['estado'])) ?></span></td>
                <td style="text-align: center;">
                    <button class="btn-delete" title="Borrar Ticket" onclick="borrarTicket(<?= $t['id_ticket'] ?>)">🗑️</button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
// ==========================================
// FUNCIÓN: Borrar Ticket
// ==========================================
async function borrarTicket(idTicket) {
    const idFormat = String(idTicket).padStart(4, '0');
    
    // Confirmación para evitar clicks accidentales
    if (!confirm(`¿Estás seguro de que deseas eliminar permanentemente el ticket CT-${idFormat}?\nEsta acción no se puede deshacer y borrará los historiales asociados.`)) {
        return;
    }

    const formData = new FormData();
    formData.append('action', 'delete_ticket');
    formData.append('id_ticket', idTicket);

    try {
        const response = await fetch('tickets.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Animación sencilla antes de remover la fila de la vista
            const row = document.querySelector(`tr[data-id="${idTicket}"]`);
            row.style.transition = "opacity 0.3s ease";
            row.style.opacity = "0";
            setTimeout(() => row.remove(), 300);
        } else {
            alert('Error al borrar el ticket: ' + data.error);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Ocurrió un error de conexión con el servidor.');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('searchInput');
    const statusFilter = document.getElementById('statusFilter');
    const tableBody = document.getElementById('tableBody');
    const sortableHeaders = document.querySelectorAll('.sortable');
    let currentSort = { column: null, order: 'asc' };

    // FILTRADO (Búsqueda + Estado)
    function filterTable() {
        const rows = Array.from(tableBody.getElementsByClassName('ticket-row'));
        const searchTerm = searchInput.value.toLowerCase().trim();
        const statusTerm = statusFilter.value;

        rows.forEach(row => {
            const searchData = row.getAttribute('data-search');
            const rowStatus = row.getAttribute('data-estado');

            const matchSearch = searchData.includes(searchTerm);
            const matchStatus = (statusTerm === 'todos') || (rowStatus === statusTerm);

            if (matchSearch && matchStatus) {
                row.classList.remove('hidden-row');
            } else {
                row.classList.add('hidden-row');
            }
        });
    }

    searchInput.addEventListener('input', filterTable);
    statusFilter.addEventListener('change', filterTable);

    // ORDENAMIENTO (ID y Fecha)
    sortableHeaders.forEach(header => {
        header.addEventListener('click', () => {
            const rows = Array.from(tableBody.getElementsByClassName('ticket-row'));
            const sortType = header.getAttribute('data-sort');

            if (currentSort.column === sortType) {
                currentSort.order = currentSort.order === 'asc' ? 'desc' : 'asc';
            } else {
                currentSort.column = sortType;
                currentSort.order = 'asc';
            }

            sortableHeaders.forEach(th => th.querySelector('.sort-icon').textContent = '⇅');
            header.querySelector('.sort-icon').textContent = currentSort.order === 'asc' ? '↑' : '↓';

            rows.sort((a, b) => {
                let valA = parseInt(a.getAttribute(`data-${sortType}`));
                let valB = parseInt(b.getAttribute(`data-${sortType}`));

                if (valA < valB) return currentSort.order === 'asc' ? -1 : 1;
                if (valA > valB) return currentSort.order === 'asc' ? 1 : -1;
                return 0;
            });

            rows.forEach(row => tableBody.appendChild(row));
        });
    });
});
</script>

</body>
</html>