<?php
session_start();
if (!isset($_SESSION['nivel_acceso']) || $_SESSION['nivel_acceso'] < 80) {
    header("Location: login.php");
    exit();
}
require_once __DIR__ . '/../../libs/config/database.php';
$conn = AuthDatabase::getInstance();

// Consultar los últimos tickets activos o recientemente cerrados
$query = "
    SELECT t.id_ticket, t.titulo, t.estado, t.fecha_creacion, u.nombre as cliente
    FROM ticket t
    JOIN cliente c ON t.id_cliente = c.id_cliente
    JOIN usuario u ON c.id_usuario = u.id_usuario
    ORDER BY t.id_ticket DESC
    LIMIT 10
";
$tickets = $conn->query($query)->fetchAll(PDO::FETCH_ASSOC);

// Función ajustada a 5 pasos (Mapeamos 'finalizado_pendiente_pago' a 'en_proceso' por retrocompatibilidad)
function calcularProgresoSLA($estado) {
    $flujo = [
        'pendiente' => 1,
        'asignado' => 2,
        'en_camino' => 3,
        'en_proceso' => 4,
        'finalizado_pendiente_pago' => 4, // Absorvido por "En proceso"
        'cerrado' => 5,
        'reabierto' => 2
    ];
    return $flujo[$estado] ?? 1;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>ChapinTech | Rastreo SLA</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #020617; color: white; margin: 0; padding: 20px; }
        .container { max-width: 1000px; margin: 20px auto; background: rgba(255,255,255,.03); border: 1px solid rgba(99,230,255,.12); border-radius: 24px; padding: 40px; box-shadow: 0 0 50px rgba(34,211,238,.05); backdrop-filter: blur(18px); }
        .btn-back { display: inline-block; color: #63e6ff; text-decoration: none; font-weight: 600; padding: 8px 16px; border-radius: 8px; background: rgba(99,230,255,.1); border: 1px solid rgba(99,230,255,.2); margin-bottom: 20px; transition: 0.3s; }
        .btn-back:hover { background: rgba(99,230,255,.2); transform: translateX(-5px); }
        
        .sla-card { background: #07111f; border: 1px solid rgba(255,255,255,.08); border-radius: 16px; padding: 25px; margin-bottom: 20px; }
        .sla-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255,255,255,.05); padding-bottom: 15px; margin-bottom: 25px; }
        
        .timeline { display: flex; justify-content: space-between; position: relative; }
        .timeline::before {
            content: ''; position: absolute; top: 15px; left: 0; width: 100%; height: 2px;
            background: rgba(255,255,255,.1); z-index: 1;
        }
        /* CAMBIO A 20% para ajustarse a 5 pasos */
        .step { position: relative; z-index: 2; text-align: center; width: 20%; } 
        .step-dot {
            width: 30px; height: 30px; background: #07111f; border: 2px solid rgba(255,255,255,.2);
            border-radius: 50%; margin: 0 auto 10px; transition: 0.3s;
        }
        .step.completed .step-dot { background: #63e6ff; border-color: #63e6ff; box-shadow: 0 0 15px rgba(99,230,255,.5); }
        .step.current .step-dot { background: #8b5cf6; border-color: #8b5cf6; animation: pulse 2s infinite; }
        .step-label { font-size: 0.8rem; color: rgba(255,255,255,.6); font-weight: 600; }
        .step.completed .step-label { color: #63e6ff; }
        .step.current .step-label { color: #8b5cf6; }

        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(139,92,246, 0.7); }
            70% { box-shadow: 0 0 0 10px rgba(139,92,246, 0); }
            100% { box-shadow: 0 0 0 0 rgba(139,92,246, 0); }
        }
    </style>
</head>
<body>
<div class="container">
    <a href="../../admin.php" class="btn-back">← Volver al Panel Admin</a>
    <h2 style="font-family: 'Orbitron'; color: #63e6ff; margin-bottom: 5px;">Monitor de SLA (Línea de Tiempo)</h2>
    <p style="color: rgba(255,255,255,.5); margin-bottom: 30px;">Seguimiento visual del cumplimiento de tiempos y estados operativos.</p>

    <?php if(empty($tickets)): ?>
        <div style="text-align: center; padding: 40px; color: rgba(255,255,255,.5); border: 1px dashed rgba(255,255,255,.2); border-radius: 16px;">
            No hay tickets registrados en el sistema.
        </div>
    <?php else: ?>
        <?php foreach($tickets as $t): 
            $nivelSLA = calcularProgresoSLA($t['estado']);
        ?>
        <div class="sla-card">
            <div class="sla-header">
                <div>
                    <strong style="font-family: 'Orbitron'; color: #fff; font-size: 1.1rem;">
                        CT-<?= str_pad($t['id_ticket'], 4, '0', STR_PAD_LEFT) ?>
                    </strong>
                    <span style="color: rgba(255,255,255,.5); margin-left: 10px;">Cliente: <?= htmlspecialchars($t['cliente']) ?></span>
                </div>
                <div style="font-size: 0.85rem; color: rgba(255,255,255,.4);">
                    Estado BD: <?= strtoupper($t['estado']) ?>
                </div>
            </div>

            <?php if ($t['estado'] === 'cancelado'): ?>
                <div style="text-align: center; color: #ff4d4d; font-weight: bold; padding: 10px; background: rgba(255,77,77,0.1); border-radius: 8px;">
                    ❌ TICKET CANCELADO
                </div>
            <?php else: ?>
                <div class="timeline">
                    <div class="step <?= ($nivelSLA >= 1) ? 'completed' : '' ?> <?= ($nivelSLA == 1) ? 'current' : '' ?>">
                        <div class="step-dot"></div><div class="step-label">Pendiente</div>
                    </div>
                    <div class="step <?= ($nivelSLA >= 2) ? 'completed' : '' ?> <?= ($nivelSLA == 2) ? 'current' : '' ?>">
                        <div class="step-dot"></div><div class="step-label">Asignado</div>
                    </div>
                    <div class="step <?= ($nivelSLA >= 3) ? 'completed' : '' ?> <?= ($nivelSLA == 3) ? 'current' : '' ?>">
                        <div class="step-dot"></div><div class="step-label">En Camino</div>
                    </div>
                    <div class="step <?= ($nivelSLA >= 4) ? 'completed' : '' ?> <?= ($nivelSLA == 4) ? 'current' : '' ?>">
                        <div class="step-dot"></div><div class="step-label">En Proceso</div>
                    </div>
                    <div class="step <?= ($nivelSLA == 5) ? 'completed' : '' ?> <?= ($nivelSLA == 5) ? 'current' : '' ?>">
                        <div class="step-dot"></div><div class="step-label">Finalizado</div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
</body>
</html>