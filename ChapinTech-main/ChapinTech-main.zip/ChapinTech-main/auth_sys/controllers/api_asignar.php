<?php
// auth_sys/controllers/api_asignar.php
session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../libs/config/database.php';
$conn = AuthDatabase::getInstance();

$action = $_REQUEST['action'] ?? '';

try {
    if ($action === 'get_tecnicos') {
        // BUSCAMOS POR USUARIO, usando LEFT JOIN por si aún no tienen perfil de técnico
        $stmt = $conn->query("
            SELECT u.id_usuario, u.nombre, COALESCE(t.especialidad, 'General') AS especialidad 
            FROM usuario u 
            LEFT JOIN tecnico t ON u.id_usuario = t.id_usuario 
            WHERE u.tipo = 'tecnico' AND u.activo = 1 
            ORDER BY u.nombre ASC
        ");
        echo json_encode(['success' => true, 'tecnicos' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    
    } elseif ($action === 'asignar') {
        $id_ticket = $_POST['id_ticket'] ?? null;
        $id_usuario_tecnico = $_POST['id_usuario'] ?? null; // Ahora recibimos el ID del usuario
        
        if (!$id_ticket || !$id_usuario_tecnico) {
            throw new Exception("Datos incompletos para la asignación.");
        }

        // 1. Verificar si el usuario ya tiene su perfil en la tabla 'tecnico'
        $stmtCheck = $conn->prepare("SELECT id_tecnico FROM tecnico WHERE id_usuario = ?");
        $stmtCheck->execute([$id_usuario_tecnico]);
        $tecnicoRow = $stmtCheck->fetch(PDO::FETCH_ASSOC);

        if ($tecnicoRow) {
            // Ya existía, tomamos su ID
            $id_tecnico_real = $tecnicoRow['id_tecnico'];
        } else {
            // 2. Si no existe, lo creamos automáticamente con valores por defecto
            $stmtInsert = $conn->prepare("INSERT INTO tecnico (id_usuario, especialidad, estado_disponibilidad) VALUES (?, 'General', 'disponible')");
            $stmtInsert->execute([$id_usuario_tecnico]);
            $id_tecnico_real = $conn->lastInsertId();
        }

        // 3. Asignamos el ticket usando el id_tecnico_real
        $stmt = $conn->prepare("UPDATE ticket SET id_tecnico = ?, estado = 'asignado', fecha_asignacion = NOW() WHERE id_ticket = ?");
        $stmt->execute([$id_tecnico_real, $id_ticket]);

        echo json_encode(['success' => true]);
    } else {
        throw new Exception("Acción no válida.");
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>