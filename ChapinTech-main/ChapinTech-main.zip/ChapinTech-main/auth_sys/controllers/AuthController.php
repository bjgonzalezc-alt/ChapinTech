<?php
// auth_sys/controllers/AuthController.php

session_start();

require_once __DIR__ . '/../libs/config/database.php';
require_once __DIR__ . '/../libs/config/mailer_setup.php';

date_default_timezone_set('America/Guatemala');

class AuthController {

    private $conn;

    public function __construct() {
        $this->conn = AuthDatabase::getInstance();
    }

    private function obtenerNivelAcceso($tipo) {
        switch (strtolower($tipo)) {
            case 'administrador':
                return 100;

            case 'soporte':
                return 80;

            case 'tecnico':
                return 50;

            default:
                return 10;
        }
    }

    public function loginGoogle($datosPost) {
        try {
            $credential = $datosPost['credential'] ?? '';

            if (empty($credential)) {
                throw new Exception("No se recibió credencial Google.");
            }

            $googleData = json_decode(
                file_get_contents("https://oauth2.googleapis.com/tokeninfo?id_token=" . $credential),
                true
            );

            if (!$googleData || !isset($googleData['email'])) {
                throw new Exception("No se pudo validar Google.");
            }

            $email = filter_var($googleData['email'], FILTER_SANITIZE_EMAIL);
            $nombre = htmlspecialchars(strip_tags($googleData['name'] ?? 'Cliente'));

            $stmt = $this->conn->prepare("
                SELECT id_usuario, nombre, email, tipo, activo, bloqueado
                FROM usuario
                WHERE email = :email
                LIMIT 1
            ");

            $stmt->bindParam(":email", $email);
            $stmt->execute();

            if ($stmt->rowCount() === 0) {
                $_SESSION['google_nombre'] = $nombre;
                $_SESSION['google_email'] = $email;

                header("Location: ../views/register.php");
                exit();
            }

            unset($_SESSION['google_nombre']);
            unset($_SESSION['google_email']);
            unset($_SESSION['email_temporal_otp']);

            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($usuario['bloqueado'] == 1 || $usuario['activo'] == 0) {
                throw new Exception("Tu cuenta está suspendida.");
            }

            $nivelAcceso = $this->obtenerNivelAcceso($usuario['tipo']);

            $otpCode = random_int(100000, 999999);
            $otpExpiracion = date("Y-m-d H:i:s", strtotime('+10 minutes'));

            $actualizarOTP = $this->conn->prepare("
                UPDATE usuario
                SET otp_code = :otp_code,
                    otp_expiracion = :otp_expiracion
                WHERE id_usuario = :id_usuario
            ");

            $actualizarOTP->bindParam(":otp_code", $otpCode);
            $actualizarOTP->bindParam(":otp_expiracion", $otpExpiracion);
            $actualizarOTP->bindParam(":id_usuario", $usuario['id_usuario']);
            $actualizarOTP->execute();

            $_SESSION['login_2fa_id'] = $usuario['id_usuario'];
            $_SESSION['login_2fa_nombre'] = $usuario['nombre'];
            $_SESSION['login_2fa_email'] = $usuario['email'];
            $_SESSION['login_2fa_rol'] = $usuario['tipo'];
            $_SESSION['login_2fa_nivel'] = $nivelAcceso;

            $envioCorreo = enviarCorreoOTP($usuario['email'], $otpCode, $usuario['nombre']);

            if ($envioCorreo !== true) {
                throw new Exception("No se pudo enviar OTP: " . $envioCorreo);
            }

            header("Location: ../views/verify_otp.php");
            exit();

        } catch (Exception $e) {
            $_SESSION['error_login'] = $e->getMessage();
            header("Location: ../views/login.php");
            exit();
        }
    }

    public function completarRegistroGoogle($datosPost) {
        try {
            if (!isset($_SESSION['google_nombre']) || !isset($_SESSION['google_email'])) {
                throw new Exception("La sesión Google expiró.");
            }

            $nombre = $_SESSION['google_nombre'];
            $email = $_SESSION['google_email'];
            $telefono = htmlspecialchars(strip_tags(trim($datosPost['telefono'])));
            $direccion = htmlspecialchars(strip_tags(trim($datosPost['direccion'])));

            if (empty($telefono) || empty($direccion)) {
                throw new Exception("Debes ingresar teléfono y dirección.");
            }

            $passwordHash = password_hash(random_bytes(16), PASSWORD_DEFAULT);
            $otpCode = random_int(100000, 999999);
            $otpExpiracion = date("Y-m-d H:i:s", strtotime('+15 minutes'));

            $this->conn->beginTransaction();

            $queryUsuario = "
                INSERT INTO usuario 
                (nombre, email, contrasena, tipo, telefono, otp_code, otp_expiracion, email_verificado) 
                VALUES 
                (:nombre, :email, :contrasena, 'cliente', :telefono, :otp_code, :otp_expiracion, 0)
            ";

            $stmtUsuario = $this->conn->prepare($queryUsuario);
            $stmtUsuario->bindParam(":nombre", $nombre);
            $stmtUsuario->bindParam(":email", $email);
            $stmtUsuario->bindParam(":contrasena", $passwordHash);
            $stmtUsuario->bindParam(":telefono", $telefono);
            $stmtUsuario->bindParam(":otp_code", $otpCode);
            $stmtUsuario->bindParam(":otp_expiracion", $otpExpiracion);
            $stmtUsuario->execute();

            $idUsuarioNuevo = $this->conn->lastInsertId();

            $queryCliente = "
                INSERT INTO cliente (id_usuario, direccion)
                VALUES (:id_usuario, :direccion)
            ";

            $stmtCliente = $this->conn->prepare($queryCliente);
            $stmtCliente->bindParam(":id_usuario", $idUsuarioNuevo);
            $stmtCliente->bindParam(":direccion", $direccion);
            $stmtCliente->execute();

            $this->conn->commit();

            unset($_SESSION['google_nombre']);
            unset($_SESSION['google_email']);

            $_SESSION['email_temporal_otp'] = $email;

            $envioCorreo = enviarCorreoOTP($email, $otpCode, $nombre);

            if ($envioCorreo !== true) {
                throw new Exception("Cuenta creada, pero hubo error enviando OTP: " . $envioCorreo);
            }

            header("Location: ../views/verify_otp.php");
            exit();

        } catch (Exception $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }

            $_SESSION['error_registro'] = $e->getMessage();
            header("Location: ../views/register.php");
            exit();
        }
    }

    public function verificarOTP($datosPost) {
        try {
            if (isset($_SESSION['login_2fa_email'])) {
                $email = $_SESSION['login_2fa_email'];
            } else if (isset($_SESSION['email_temporal_otp'])) {
                $email = $_SESSION['email_temporal_otp'];
            } else {
                throw new Exception("Sesión caducada.");
            }

            $codigoIngresado = htmlspecialchars(strip_tags(trim($datosPost['otp_code'])));

            $query = "
                SELECT id_usuario, nombre, email, tipo, otp_expiracion
                FROM usuario
                WHERE email = :email
                AND otp_code = :otp_code
                LIMIT 1
            ";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":email", $email);
            $stmt->bindParam(":otp_code", $codigoIngresado);
            $stmt->execute();

            if ($stmt->rowCount() === 0) {
                throw new Exception("Código incorrecto.");
            }

            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

            if (date("Y-m-d H:i:s") > $usuario['otp_expiracion']) {
                throw new Exception("Código expirado.");
            }

            $queryUpdate = "
                UPDATE usuario
                SET email_verificado = 1,
                    otp_code = NULL,
                    otp_expiracion = NULL,
                    ultimo_acceso = NOW()
                WHERE id_usuario = :id_usuario
            ";

            $stmtUpdate = $this->conn->prepare($queryUpdate);
            $stmtUpdate->bindParam(":id_usuario", $usuario['id_usuario']);
            $stmtUpdate->execute();

            $_SESSION['usuario_id'] = $usuario['id_usuario'];
            $_SESSION['usuario_nombre'] = $usuario['nombre'];
            $_SESSION['usuario_email'] = $usuario['email'];
            $_SESSION['usuario_rol'] = $usuario['tipo'];

            

            $nivelAcceso = $this->obtenerNivelAcceso($usuario['tipo']);
            $_SESSION['nivel_acceso'] = $nivelAcceso;

            unset($_SESSION['email_temporal_otp']);
            unset($_SESSION['login_2fa_id']);
            unset($_SESSION['login_2fa_nombre']);
            unset($_SESSION['login_2fa_email']);
            unset($_SESSION['login_2fa_rol']);
            unset($_SESSION['login_2fa_nivel']);

            // Redirección final después de verificar OTP
            // Admin y soporte van al panel de usuarios
            // Cliente y técnico van al index principal

// Redirección según nivel de acceso
if ($nivelAcceso >= 80) { 
    header("Location: ../admin.php"); 
} else if ($nivelAcceso == 50) { 
    header("Location: ../../Tecnico/techportal.php");
} else { 
    header("Location: ../../index.html"); 
}
 exit();

        } catch (Exception $e) {
            $_SESSION['error_otp'] = $e->getMessage();
            header("Location: ../views/verify_otp.php");
            exit();
        }
    }

    public function registrarUsuario($datosPost) {
        $_SESSION['error_registro'] = "Usa el botón de Google para registrarte.";
        header("Location: ../views/login.php");
        exit();
    }

    public function loginUsuario($datosPost) {
        $_SESSION['error_login'] = "Usa el botón de Google para iniciar sesión.";
        header("Location: ../views/login.php");
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $authController = new AuthController();

    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'google_login':
                $authController->loginGoogle($_POST);
                break;

            case 'complete_google_profile':
                $authController->completarRegistroGoogle($_POST);
                break;

            case 'verify_otp':
                $authController->verificarOTP($_POST);
                break;

            case 'register':
                $authController->registrarUsuario($_POST);
                break;

            case 'login':
                $authController->loginUsuario($_POST);
                break;

            default:
                $_SESSION['error_login'] = "Acción no reconocida.";
                header("Location: ../views/login.php");
                exit();
        }
    }
}
?>