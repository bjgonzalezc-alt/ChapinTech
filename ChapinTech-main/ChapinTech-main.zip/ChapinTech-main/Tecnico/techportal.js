// ========================================
// PORTAL TÉCNICO CHAPINTECH
// VERSION FINAL ESTABLE
// ========================================

document.addEventListener('DOMContentLoaded', () => {

  const queueScreen = document.getElementById('queueScreen');
  const activeScreen = document.getElementById('activeScreen');
  const queueList = document.getElementById('queueList');
  const searchInput = document.getElementById('searchInput');
  const priorityFilter = document.getElementById('priorityFilter');

  const ticketId = document.getElementById('ticketId');
  const ticketClient = document.getElementById('ticketClient');
  const ticketLocation = document.getElementById('ticketLocation');
  const ticketProblem = document.getElementById('ticketProblem');
  const ticketStatus = document.getElementById('ticketStatus');
  const arrivalBtn = document.getElementById('arrivalBtn');
  const resolveBtn = document.getElementById('resolveBtn'); // Agregado botón resolver

  let allTickets = [];
  let currentTicketId = null;

  function showToast(msg) { alert(msg); }
  function normalizarPrioridad(p) { return String(p || 'media').toLowerCase().trim(); }
  function escapeHTML(v) {
    return String(v).replace(/[&<>'"]/g, match => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[match]);
  }

  // ========================================
  // CARGAR TICKETS
  // ========================================
  async function cargarTickets() {
    queueList.innerHTML = `<div class="skeleton-card"></div><div class="skeleton-card"></div>`;
    try {
      const respuesta = await fetch('tecnico.php');
      const text = await respuesta.text();
      const cleanText = text.replace(/^\uFEFF/, '').trim();
      
      const data = JSON.parse(cleanText);
      if (!data.success) {
        showToast(data.message || "No se pudieron cargar tickets");
        return;
      }
      allTickets = data.tickets || [];
      renderTickets();
    } catch (err) {
      console.error(err);
      showToast("Error de conexión");
    }
  }

  // ========================================
  // RENDER TICKETS
  // ========================================
  function renderTickets() {
    const searchText = (searchInput?.value || '').toLowerCase().trim();
    const priority = priorityFilter?.value || 'all';

    const filtered = allTickets.filter(t => {
      const p = normalizarPrioridad(t.prioridad);
      const matchPriority = priority === 'all' || p === priority;
      const text = `${t.id_ticket} ${t.cliente} ${t.descripcion} ${t.direccion}`.toLowerCase();
      return matchPriority && text.includes(searchText);
    });

    queueList.innerHTML = "";
    
    if(filtered.length === 0) {
       queueList.innerHTML = `<p style="text-align:center; color:gray; padding: 20px;">No hay casos disponibles.</p>`;
       return;
    }

    filtered.forEach(ticket => {
      const code = `CT-${String(ticket.id_ticket).padStart(4,'0')}`;
      
      // Diferenciar botón según estado
      let btnHtml = '';
      if(ticket.estado === 'pendiente') {
          btnHtml = `<button class="assign-btn" data-id="${ticket.id_ticket}">Asignarme</button>`;
      } else {
          btnHtml = `<button class="continue-btn primary-btn" data-id="${ticket.id_ticket}">Continuar Caso</button>`;
      }

      queueList.innerHTML += `
        <div class="ticket-card ${normalizarPrioridad(ticket.prioridad)}">
          <div style="display:flex; justify-content:space-between;">
             <h3>${code}</h3>
             <span class="status ${ticket.estado === 'pendiente' ? 'route' : 'repair'}" style="padding: 4px 8px; font-size:0.8rem; margin-bottom:0;">${ticket.estado.toUpperCase()}</span>
          </div>
          <p><strong>${escapeHTML(ticket.cliente || '')}</strong></p>
          <p>${escapeHTML(ticket.descripcion || '')}</p>
          <br>
          ${btnHtml}
        </div>
      `;
    });
  }

  // Filtros
  searchInput?.addEventListener('input', renderTickets);
  priorityFilter?.addEventListener('change', renderTickets);

  // ========================================
  // ACCIONES PRINCIPALES (DELEGACIÓN DE EVENTOS)
  // ========================================
  document.addEventListener('click', async (e) => {
    
    // 1. ASIGNAR NUEVO TICKET
    if (e.target.classList.contains('assign-btn')) {
      const id = e.target.dataset.id;
      currentTicketId = id;

      try {
        const res = await fetch('tecnico.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: `accion=asignar&id_ticket=${id}`
        });
        const data = await res.json();

        if (!data.success) {
          showToast(data.message || "Error al asignar");
          return;
        }

        abrirPantallaActiva(id, "En Camino");
      } catch (err) {
        showToast("Error de conexión");
      }
    }

    // 2. CONTINUAR TICKET EXISTENTE
    if (e.target.classList.contains('continue-btn')) {
      const id = e.target.dataset.id;
      currentTicketId = id;
      const ticket = allTickets.find(t => t.id_ticket == id);
      abrirPantallaActiva(id, ticket.estado === 'en_proceso' ? "En Proceso" : "En Camino");
    }
  });

  function abrirPantallaActiva(id, estadoVisual) {
      const code = `CT-${String(id).padStart(4,'0')}`;
      const ticket = allTickets.find(t => t.id_ticket == id);
      
      ticketId.textContent = code;
      ticketClient.textContent = ticket?.cliente || "Cliente";
      ticketLocation.textContent = ticket?.direccion || "Dirección";
      ticketProblem.textContent = ticket?.descripcion || "Problema";
      ticketStatus.textContent = estadoVisual;

      // Mostrar/ocultar botones dependiendo del estado
      if(estadoVisual === "En Proceso") {
          arrivalBtn.classList.add('hidden');
          resolveBtn.classList.remove('hidden'); // Mostrar resolver
      } else {
          arrivalBtn.classList.remove('hidden');
          resolveBtn.classList.add('hidden');
      }

      queueScreen.classList.remove('active-screen');
      activeScreen.classList.add('active-screen');
  }

  // ========================================
  // LLEGADA AL SITIO
  // ========================================
  arrivalBtn?.addEventListener('click', async () => {
    try {
      const res = await fetch('tecnico.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `accion=llegada&id_ticket=${currentTicketId}`
      });
      const data = await res.json();

      if (!data.success) {
        showToast("Error al registrar llegada");
        return;
      }

      ticketStatus.textContent = "En Proceso";
      arrivalBtn.classList.add('hidden');
      resolveBtn.classList.remove('hidden'); // Muestra botón para finalizar
      showToast("Llegada registrada, comienza a trabajar.");

    } catch (err) {
      showToast("Error de conexión");
    }
  });

  // ========================================
  // RESOLVER CASO (CERRAR)
  // ========================================
  resolveBtn?.addEventListener('click', async () => {
      if(!confirm("¿Estás seguro de que deseas cerrar este caso?")) return;

      try {
        const res = await fetch('tecnico.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: `accion=resolver&id_ticket=${currentTicketId}`
        });
        const data = await res.json();

        if (!data.success) {
          showToast("Error al cerrar el caso");
          return;
        }

        showToast("¡Trabajo excelente! El caso ha sido cerrado.");
        location.reload(); // Recarga la página para volver a la lista

      } catch (err) {
        showToast("Error de conexión");
      }
  });

  cargarTickets();
});