<?php
session_start();
ob_start();
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');

// Usamos tu conexión PDO segura en lugar de mysqli
require_once __DIR__ . '/../auth_sys/libs/config/database.php';
$conn = AuthDatabase::getInstance();

while (ob_get_level()) ob_end_clean();

// Validar que un técnico real esté conectado
if(!isset($_SESSION['usuario_id']) || $_SESSION['nivel_acceso'] != 50){
    echo json_encode(["success" => false, "message" => "Sesión expirada o no autorizada."]);
    exit;
}

$id_usuario = $_SESSION['usuario_id'];

// Obtener el ID de técnico real enlazado a este usuario
$stmtTech = $conn->prepare("SELECT id_tecnico FROM tecnico WHERE id_usuario = ?");
$stmtTech->execute([$id_usuario]);
$techData = $stmtTech->fetch(PDO::FETCH_ASSOC);

if(!$techData) {
    echo json_encode(["success" => false, "message" => "Tu usuario no tiene un perfil de técnico asignado."]);
    exit;
}
$id_tecnico = $techData['id_tecnico'];

// Recibir datos
$accion = $_POST['accion'] ?? '';
$id_ticket = $_POST['id_ticket'] ?? $_GET['id_ticket'] ?? 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if ($accion === 'asignar') {
            // El técnico toma un ticket pendiente
            $sql = "UPDATE ticket SET estado = 'en_camino', id_tecnico = ?, fecha_asignacion = NOW() WHERE id_ticket = ? AND estado IN ('pendiente', 'asignado')";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$id_tecnico, $id_ticket]);

            if ($stmt->rowCount() > 0) {
                $conn->prepare("UPDATE tecnico SET estado_disponibilidad = 'ocupado' WHERE id_tecnico = ?")->execute([$id_tecnico]);
                echo json_encode(["success" => true]);
            } else {
                echo json_encode(["success" => false, "message" => "Este ticket ya fue tomado o no está disponible."]);
            }
            exit;
        }

        if ($accion === 'llegada') {
            // 1. El técnico llega y el estado cambia a "en_proceso"
            $sql = "UPDATE ticket SET estado = 'en_proceso', fecha_inicio = NOW() WHERE id_ticket = ? AND id_tecnico = ?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$id_ticket, $id_tecnico]);
            
            if ($stmt->rowCount() > 0) {
                // 2. Obtener los datos del cliente para notificarle
                $stmtCliente = $conn->prepare("
                    SELECT u.id_usuario, u.nombre, u.email 
                    FROM ticket t
                    JOIN cliente c ON t.id_cliente = c.id_cliente
                    JOIN usuario u ON c.id_usuario = u.id_usuario
                    WHERE t.id_ticket = ?
                ");
                $stmtCliente->execute([$id_ticket]);
                $cliente = $stmtCliente->fetch(PDO::FETCH_ASSOC);

                if ($cliente) {
                    // A. Generar notificación en la campanita del sistema
                    $mensajePush = "Tu técnico ya está en el lugar. El ticket CT-" . str_pad($id_ticket, 4, '0', STR_PAD_LEFT) . " está En Proceso 🛠️.";
                    $conn->prepare("INSERT INTO notificacion (id_usuario, id_ticket, tipo, mensaje, fecha_envio) VALUES (?, ?, 'push', ?, NOW())")
                         ->execute([$cliente['id_usuario'], $id_ticket, $mensajePush]);

                    // B. Enviar un correo electrónico real usando tu Mailer
                    try {
                        require_once __DIR__ . '/../auth_sys/libs/config/mailer_setup.php';
                        $mail = configurarMailer();
                        $mail->setFrom('bennygonza2004@gmail.com', 'ChapinTech Soporte');
                        $mail->addAddress($cliente['email'], $cliente['nombre']);
                        $mail->Subject = "El tecnico ha llegado - ChapinTech";
                        $mail->isHTML(true);
                        $mail->Body = "
                            <div style='font-family: Arial, sans-serif; color: #333;'>
                                <h2 style='color: #3ba7ff;'>¡Hola {$cliente['nombre']}!</h2>
                                <p>Te informamos que nuestro técnico acaba de registrar su llegada a tu ubicación.</p>
                                <p><strong>Estado del ticket:</strong> En Proceso 🛠️</p>
                                <hr style='border: 1px solid #eee;' />
                                <p style='font-size: 0.8rem; color: #999;'>Gracias por confiar en ChapinTech.</p>
                            </div>
                        ";
                        $mail->send();
                    } catch (Exception $e) {
                        // Si falla el correo, el técnico igual puede trabajar
                    }
                }
                
                echo json_encode(["success" => true]);
            } else {
                echo json_encode(["success" => false, "message" => "No se pudo registrar la llegada."]);
            }
            exit;
        }

        if ($accion === 'resolver') {
            // El técnico termina el trabajo
            $sql = "UPDATE ticket SET estado = 'cerrado', fecha_cierre = NOW() WHERE id_ticket = ? AND id_tecnico = ?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$id_ticket, $id_tecnico]);
            
            if ($stmt->rowCount() > 0) {
                $conn->prepare("UPDATE tecnico SET estado_disponibilidad = 'disponible' WHERE id_tecnico = ?")->execute([$id_tecnico]);
            }
            echo json_encode(["success" => $stmt->rowCount() > 0]);
            exit;
        }

    } catch(Exception $e) {
        echo json_encode(["success" => false, "message" => "Error de base de datos."]);
        exit;
    }
}

// ========================================
// LISTAR TICKETS (Pantalla principal)
// ========================================
// Busca tickets libres (pendientes) O los que ya le pertenecen a este técnico
$sql = "SELECT t.id_ticket, t.descripcion, t.tipo_servicio, t.estado, t.prioridad, t.fecha_creacion, c.direccion, u.nombre AS cliente
        FROM ticket t
        INNER JOIN cliente c ON t.id_cliente = c.id_cliente
        INNER JOIN usuario u ON c.id_usuario = u.id_usuario
        WHERE t.estado = 'pendiente' 
           OR (t.id_tecnico = ? AND t.estado IN ('asignado', 'en_camino', 'en_proceso'))
        ORDER BY FIELD(t.estado, 'en_proceso', 'en_camino', 'asignado', 'pendiente'), t.fecha_creacion ASC";

$stmt = $conn->prepare($sql);
$stmt->execute([$id_tecnico]);
$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(["success" => true, "tickets" => $tickets]);
?>