// ========================================
// PORTAL TÉCNICO CHAPINTECH
// VERSION FINAL ESTABLE
// ========================================

document.addEventListener('DOMContentLoaded', () => {

  // ========================================
  // ELEMENTOS
  // ========================================

  const queueScreen = document.getElementById('queueScreen');
  const activeScreen = document.getElementById('activeScreen');
  const queueList = document.getElementById('queueList');

  const searchInput = document.getElementById('searchInput');
  const priorityFilter = document.getElementById('priorityFilter');

  const ticketId = document.getElementById('ticketId');
  const ticketClient = document.getElementById('ticketClient');
  const ticketLocation = document.getElementById('ticketLocation');
  const ticketProblem = document.getElementById('ticketProblem');
  const ticketPriority = document.getElementById('ticketPriority');
  const ticketStatus = document.getElementById('ticketStatus');

  const mainTimer = document.getElementById('mainTimer');

  const arrivalBtn = document.getElementById('arrivalBtn');

  // ========================================
  // VARIABLES
  // ========================================

  let allTickets = [];
  let travelTime = 900;
  let confirmationTime = 300;
  let currentTicketId = null;
  let timerInterval = null;

  // ========================================
  // TOAST SIMPLE
  // ========================================

  function showToast(msg) {
    alert(msg);
  }

  // ========================================
  // UTILIDADES
  // ========================================

  function normalizarPrioridad(p) {
    return String(p || 'media').toLowerCase().trim();
  }

  function escapeHTML(v) {
    return String(v)
      .replaceAll('&','&amp;')
      .replaceAll('<','&lt;')
      .replaceAll('>','&gt;')
      .replaceAll('"','&quot;')
      .replaceAll("'","&#039;");
  }

  // ========================================
  // CARGAR TICKETS
  // ========================================

  async function cargarTickets() {

    queueList.innerHTML = `
      <div class="skeleton-card"></div>
      <div class="skeleton-card"></div>
      <div class="skeleton-card"></div>
    `;

    try {

      const respuesta = await fetch('/ChapinTech-main/Tecnico/tecnico.php');

      if (!respuesta.ok) {
        const err = await respuesta.text();
        console.error("ERROR HTTP:", err);
        showToast("Error del servidor (500)");
        return;
      }

      let text = await respuesta.text();

      if (!text || text.trim() === "") {
        showToast("Respuesta vacía del servidor");
        return;
      }

      // limpieza de basura típica PHP
      text = text.replace(/^\uFEFF/, '').replace(/¿/g, '').trim();

      let data;
      try {
        data = JSON.parse(text);
      } catch (e) {
        console.error("JSON inválido:", text);
        showToast("Error JSON del servidor");
        return;
      }

      if (!data.success) {
        showToast("No se pudieron cargar tickets");
        return;
      }

      allTickets = data.tickets || [];
      renderTickets();

    } catch (err) {
      console.error(err);
      showToast("Error de conexión");
    }
  }

  // ========================================
  // RENDER TICKETS
  // ========================================

  function renderTickets() {

    const searchText = (searchInput?.value || '').toLowerCase().trim();
    const priority = priorityFilter?.value || 'all';

    const filtered = allTickets.filter(t => {

      const p = normalizarPrioridad(t.prioridad);

      const matchPriority = priority === 'all' || p === priority;

      const text = `
        ${t.id_ticket}
        ${t.cliente}
        ${t.descripcion}
        ${t.direccion}
      `.toLowerCase();

      return matchPriority && text.includes(searchText);
    });

    queueList.innerHTML = "";

    filtered.forEach(ticket => {

      const code = `CT-${String(ticket.id_ticket).padStart(4,'0')}`;

      queueList.innerHTML += `
        <div class="ticket-card ${normalizarPrioridad(ticket.prioridad)}">
          <h3>${code}</h3>
          <p>${escapeHTML(ticket.cliente || '')}</p>
          <p>${escapeHTML(ticket.descripcion || '')}</p>

          <button class="assign-btn" data-id="${ticket.id_ticket}">
            Asignarme
          </button>
        </div>
      `;
    });
  }

  // ========================================
  // ASIGNAR TICKET
  // ========================================

  document.addEventListener('click', async (e) => {

    if (!e.target.classList.contains('assign-btn')) return;

    const btn = e.target;
    const id = btn.dataset.id;

    currentTicketId = id;

    const code = `CT-${String(id).padStart(4,'0')}`;

    ticketId.textContent = code;

    queueScreen.classList.remove('active-screen');
    activeScreen.classList.add('active-screen');

    try {

      const res = await fetch('tecnico.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `accion=asignar&id_ticket=${id}`
      });

      const data = await res.json();

      if (!data.success) {
        showToast(data.message || "Error al asignar");
        return;
      }

      showToast("Ticket asignado");

    } catch (err) {
      console.error(err);
      showToast("Error de conexión");
    }
  });

  // ========================================
  // LLEGADA
  // ========================================

  arrivalBtn?.addEventListener('click', async () => {

    try {

      const res = await fetch('tecnico.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `accion=llegada&id_ticket=${currentTicketId}`
      });

      const data = await res.json();

      if (!data.success) {
        showToast(data.message || "Error llegada");
        return;
      }

      ticketStatus.textContent = "Esperando confirmación";

      showToast("Llegada registrada");

    } catch (err) {
      console.error(err);
      showToast("Error de conexión");
    }
  });

  // ========================================
  // INIT
  // ========================================

  cargarTickets();

});