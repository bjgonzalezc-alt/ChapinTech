    <?php
    session_start();

    if(!isset($_SESSION['usuario_id'])){
        header("Location: ../auth_sys/views/login.php");
        exit();
    }

    if($_SESSION['nivel_acceso'] != 50){
        header("Location: ../index.php");
        exit();
    }
    ?>

    <?php include 'techportal.html'; ?>