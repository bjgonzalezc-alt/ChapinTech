<?php

ob_start();
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');

require_once '../Conexion/conexion.php';

// 🔥 LIMPIEZA TOTAL DE SALIDA (CRÍTICO)
while (ob_get_level()) {
    ob_end_clean();
}

// ========================================
// OBTENER ESTADO DE UN TICKET
// ========================================
if (isset($_GET['id_ticket'])) {

    $id_ticket = $_GET['id_ticket'];

    $sql = "SELECT estado FROM ticket WHERE id_ticket = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $id_ticket);
    $stmt->execute();

    $resultado = $stmt->get_result();
    $ticket = $resultado->fetch_assoc();

    echo json_encode([
        "success" => true,
        "ticket" => $ticket
    ], JSON_UNESCAPED_UNICODE);

    exit;
}

// ========================================
// PETICIONES POST
// ========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $accion = $_POST['accion'] ?? '';
    $id_ticket = $_POST['id_ticket'] ?? 0;

    // ========================================
    // ASIGNAR TICKET
    // ========================================
    if ($accion === 'asignar') {

        $id_tecnico = 1;

        $sql = "UPDATE ticket
                SET estado = 'en_camino',
                    id_tecnico = ?,
                    fecha_asignacion = NOW()
                WHERE id_ticket = ?
                AND estado = 'abierto'";

        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("ii", $id_tecnico, $id_ticket);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {

            $sqlTecnico = "UPDATE tecnico
                           SET estado_disponibilidad = 'ocupado'
                           WHERE id_tecnico = ?";

            $stmtTecnico = $conexion->prepare($sqlTecnico);
            $stmtTecnico->bind_param("i", $id_tecnico);
            $stmtTecnico->execute();

            echo json_encode(["success" => true]);
        } else {
            echo json_encode([
                "success" => false,
                "message" => "Este ticket ya fue tomado por otro técnico."
            ]);
        }

        exit;
    }

    // ========================================
    // LLEGADA
    // ========================================
    if ($accion === 'llegada') {

        $sqlCheck = "SELECT estado FROM ticket WHERE id_ticket = ?";
        $stmtCheck = $conexion->prepare($sqlCheck);
        $stmtCheck->bind_param("i", $id_ticket);
        $stmtCheck->execute();

        $ticket = $stmtCheck->get_result()->fetch_assoc();

        if ($ticket && $ticket['estado'] === 'esperando_confirmacion') {
            echo json_encode([
                "success" => false,
                "message" => "Ya se notificó llegada, espera respuesta del cliente."
            ]);
            exit;
        }

        $sql = "UPDATE ticket
                SET estado = 'esperando_confirmacion',
                    fecha_inicio = NOW()
                WHERE id_ticket = ?";

        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("i", $id_ticket);

        if ($stmt->execute()) {

            // cliente
            $sqlCliente = "SELECT u.nombre, u.correo, t.id_ticket
                           FROM ticket t
                           INNER JOIN cliente c ON t.id_cliente = c.id_cliente
                           INNER JOIN usuario u ON c.id_usuario = u.id_usuario
                           WHERE t.id_ticket = ?";

            $stmtCliente = $conexion->prepare($sqlCliente);
            $stmtCliente->bind_param("i", $id_ticket);
            $stmtCliente->execute();

            $cliente = $stmtCliente->get_result()->fetch_assoc();

            if ($cliente) {
                try {
                    $mail = configurarMailer();
                    $mail->addAddress($cliente['correo'], $cliente['nombre']);
                    $mail->Subject = "Técnico en sitio | ChapinTech";
                    $mail->isHTML(true);

                    $mail->Body = "
                        <h2>Hola {$cliente['nombre']}</h2>
                        <p>El técnico ya llegó al sitio.</p>
                        <strong>ESPERANDO CONFIRMACIÓN</strong>
                        <br><br>
                        <strong>Ticket:</strong> #{$cliente['id_ticket']}
                    ";

                    $mail->send();
                } catch (Exception $e) {
                    error_log($e->getMessage());
                }
            }

            echo json_encode(["success" => true]);
        } else {
            echo json_encode(["success" => false]);
        }

        exit;
    }

    // ========================================
    // ESCALAR
    // ========================================
    if ($accion === 'escalar') {

        $sql = "UPDATE ticket SET estado = 'escalado' WHERE id_ticket = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("i", $id_ticket);

        echo json_encode([
            "success" => $stmt->execute()
        ]);

        exit;
    }

    // ========================================
    // RESOLVER
    // ========================================
    if ($accion === 'resolver') {

        $sql = "UPDATE ticket SET estado = 'resuelto' WHERE id_ticket = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("i", $id_ticket);

        if ($stmt->execute()) {

            $id_tecnico = 1;

            $sqlTecnico = "UPDATE tecnico
                           SET estado_disponibilidad = 'disponible'
                           WHERE id_tecnico = ?";

            $stmtTecnico = $conexion->prepare($sqlTecnico);
            $stmtTecnico->bind_param("i", $id_tecnico);
            $stmtTecnico->execute();

            echo json_encode(["success" => true]);
        } else {
            echo json_encode(["success" => false]);
        }

        exit;
    }

    // ========================================
    // LIBERAR
    // ========================================
    if ($accion === 'liberar') {

        $sql = "UPDATE ticket SET estado='abierto', id_tecnico=NULL WHERE id_ticket=?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("i", $id_ticket);

        echo json_encode([
            "success" => $stmt->execute()
        ]);

        exit;
    }

    echo json_encode([
        "success" => false,
        "message" => "Acción no reconocida."
    ]);

    exit;
}

// ========================================
// LISTAR TICKETS
// ========================================
$sql = "SELECT 
            t.id_ticket,
            t.descripcion,
            t.tipo_servicio,
            t.estado,
            t.prioridad,
            t.fecha_creacion,
            c.direccion,
            u.nombre AS cliente
        FROM ticket t
        INNER JOIN cliente c ON t.id_cliente = c.id_cliente
        INNER JOIN usuario u ON c.id_usuario = u.id_usuario
        WHERE t.estado = 'abierto'
        ORDER BY t.fecha_creacion ASC";

$resultado = $conexion->query($sql);

$tickets = [];

while ($fila = $resultado->fetch_assoc()) {
    $tickets[] = $fila;
}

echo json_encode([
    "success" => true,
    "tickets" => $tickets
], JSON_UNESCAPED_UNICODE);