<?php
session_start();

if(!isset($_SESSION['usuario_id'])){
    header("Location: auth_sys/views/login.php");
    exit();
}
?>

<?php include 'index.html'; ?>