<?php
// soporte/crear_ticket.php

session_start();

header("Content-Type: application/json; charset=utf-8");

// Carga tu conexión existente.
require_once __DIR__ . "/../Conexion/conexion.php";

// Carga el mailer que ya usas para OTP y ahora también para tickets.
require_once __DIR__ . "/../auth_sys/config/mailer_setup.php";

// Validar método POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Método no permitido."
    ]);

    exit;
}

// Tomar usuario logueado.
$idUsuario = $_SESSION["id_usuario"]
    ?? $_SESSION["usuario_id"]
    ?? $_SESSION["user_id"]
    ?? null;

if (!$idUsuario) {
    http_response_code(401);

    echo json_encode([
        "success" => false,
        "message" => "No hay usuario activo. Inicia sesión nuevamente."
    ]);

    exit;
}

// Recibir datos del frontend.
$tipoServicio = trim($_POST["tipo_servicio"] ?? "");
$descripcion = trim($_POST["descripcion"] ?? "");
$idTarifaRaw = $_POST["id_tarifa"] ?? "";

// Importante: permite id_tarifa = 0.
if ($idTarifaRaw === "" && $idTarifaRaw !== "0") {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "No se recibió la tarifa del servicio."
    ]);

    exit;
}

$idTarifa = (int) $idTarifaRaw;

if ($tipoServicio === "" || $descripcion === "") {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Selecciona un servicio y escribe la descripción del problema."
    ]);

    exit;
}

try {
    // Iniciar transacción.
    $conexion->begin_transaction();

    // Buscar cliente según usuario logueado.
    $stmtCliente = $conexion->prepare("
        SELECT 
            c.id_cliente,
            c.direccion,
            u.nombre,
            u.email,
            u.telefono
        FROM cliente c
        INNER JOIN usuario u ON u.id_usuario = c.id_usuario
        WHERE c.id_usuario = ?
        LIMIT 1
    ");

    $stmtCliente->bind_param("i", $idUsuario);
    $stmtCliente->execute();

    $resultadoCliente = $stmtCliente->get_result();
    $cliente = $resultadoCliente->fetch_assoc();

    if (!$cliente) {
        throw new Exception("El usuario activo no tiene registro en la tabla cliente.");
    }

    $idCliente = (int) $cliente["id_cliente"];
    $nombreCliente = $cliente["nombre"];
    $correoCliente = $cliente["email"];

    // Buscar tarifa activa.
    $stmtTarifa = $conexion->prepare("
        SELECT id_tarifa, tipo_servicio, monto_base
        FROM tarifa
        WHERE id_tarifa = ? AND activo = 1
        LIMIT 1
    ");

    $stmtTarifa->bind_param("i", $idTarifa);
    $stmtTarifa->execute();

    $resultadoTarifa = $stmtTarifa->get_result();
    $tarifa = $resultadoTarifa->fetch_assoc();

    if (!$tarifa) {
        throw new Exception("No se encontró una tarifa activa para este servicio.");
    }

    $idTarifaFinal = (int) $tarifa["id_tarifa"];
    $tipoServicioFinal = $tarifa["tipo_servicio"];
    $montoBase = (float) $tarifa["monto_base"];

    // Crear ticket.
    $titulo = "Solicitud de " . $tipoServicioFinal;
    $estado = "abierto";
    $prioridad = "media";
    $idTecnico = null;

    $stmtTicket = $conexion->prepare("
        INSERT INTO ticket
        (
            id_cliente,
            id_tecnico,
            titulo,
            descripcion,
            tipo_servicio,
            id_tarifa,
            estado,
            prioridad,
            fecha_creacion
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            NOW()
        )
    ");

    $stmtTicket->bind_param(
        "iisssiss",
        $idCliente,
        $idTecnico,
        $titulo,
        $descripcion,
        $tipoServicioFinal,
        $idTarifaFinal,
        $estado,
        $prioridad
    );

    $stmtTicket->execute();

    $idTicket = $conexion->insert_id;
    $codigoTicket = "CT-" . str_pad($idTicket, 5, "0", STR_PAD_LEFT);

    // Crear control de tiempo.
    $tiempoLimite = 1200;
    $tiempoCumplido = 0;
    $liberadoAutomaticamente = 0;

    $stmtControl = $conexion->prepare("
        INSERT INTO controltiempo
        (
            id_ticket,
            tiempo_limite_segundos,
            tiempo_inicio,
            tiempo_cumplido,
            liberado_automaticamente
        )
        VALUES
        (
            ?,
            ?,
            NOW(),
            ?,
            ?
        )
    ");

    $stmtControl->bind_param(
        "iiii",
        $idTicket,
        $tiempoLimite,
        $tiempoCumplido,
        $liberadoAutomaticamente
    );

    $stmtControl->execute();

    // Crear historial.
    $estadoNuevo = "abierto";
    $accionRealizada = "Ticket creado por cliente";
    $ipOrigen = $_SERVER["REMOTE_ADDR"] ?? "";

    $stmtHistorial = $conexion->prepare("
        INSERT INTO historialservicio
        (
            id_ticket,
            id_usuario_modificador,
            estado_anterior,
            estado_nuevo,
            accion_realizada,
            fecha_cambio,
            ip_origen
        )
        VALUES
        (
            ?,
            ?,
            NULL,
            ?,
            ?,
            NOW(),
            ?
        )
    ");

    $stmtHistorial->bind_param(
        "iisss",
        $idTicket,
        $idUsuario,
        $estadoNuevo,
        $accionRealizada,
        $ipOrigen
    );

    $stmtHistorial->execute();

    // Crear mensaje inicial.
    $mensajeInicial = "El cliente creó una solicitud de soporte: " . $descripcion;

    $stmtMensaje = $conexion->prepare("
        INSERT INTO mensaje_ticket
        (
            id_ticket,
            id_remitente,
            mensaje,
            fecha_envio
        )
        VALUES
        (
            ?,
            ?,
            ?,
            NOW()
        )
    ");

    $stmtMensaje->bind_param(
        "iis",
        $idTicket,
        $idUsuario,
        $mensajeInicial
    );

    $stmtMensaje->execute();

    // Crear pago pendiente.
    $metodoPago = "efectivo";
    $estadoPago = "pendiente";

    $stmtPago = $conexion->prepare("
        INSERT INTO pago
        (
            id_ticket,
            monto,
            metodo_pago,
            estado_pago,
            fecha_pago
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            NULL
        )
    ");

    $stmtPago->bind_param(
        "idss",
        $idTicket,
        $montoBase,
        $metodoPago,
        $estadoPago
    );

    $stmtPago->execute();

    // Notificación para cliente.
    $tipoNotificacion = "push";
    $mensajeCliente = "Tu ticket {$codigoTicket} fue creado correctamente y está pendiente de asignación.";
    $leida = 0;
    $enviado = 1;

    $stmtNotificacionCliente = $conexion->prepare("
        INSERT INTO notificacion
        (
            id_usuario,
            id_ticket,
            tipo,
            mensaje,
            leida,
            fecha_envio,
            enviado_exitosamente
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            NOW(),
            ?
        )
    ");

    $stmtNotificacionCliente->bind_param(
        "iissii",
        $idUsuario,
        $idTicket,
        $tipoNotificacion,
        $mensajeCliente,
        $leida,
        $enviado
    );

    $stmtNotificacionCliente->execute();

    // Notificación para soporte y administradores.
    $mensajeSoporte = "Nuevo ticket {$codigoTicket} creado por {$nombreCliente}. Servicio: {$tipoServicioFinal}.";

    $stmtUsuariosSoporte = $conexion->prepare("
        SELECT id_usuario
        FROM usuario
        WHERE tipo IN ('soporte', 'administrador')
        AND activo = 1
    ");

    $stmtUsuariosSoporte->execute();
    $resultadoUsuariosSoporte = $stmtUsuariosSoporte->get_result();

    while ($usuarioSoporte = $resultadoUsuariosSoporte->fetch_assoc()) {
        $idUsuarioDestino = (int) $usuarioSoporte["id_usuario"];

        $stmtNotificacionSoporte = $conexion->prepare("
            INSERT INTO notificacion
            (
                id_usuario,
                id_ticket,
                tipo,
                mensaje,
                leida,
                fecha_envio,
                enviado_exitosamente
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?,
                NOW(),
                ?
            )
        ");

        $stmtNotificacionSoporte->bind_param(
            "iissii",
            $idUsuarioDestino,
            $idTicket,
            $tipoNotificacion,
            $mensajeSoporte,
            $leida,
            $enviado
        );

        $stmtNotificacionSoporte->execute();
    }

    // Confirmar todo en la base de datos.
    $conexion->commit();

    // Enviar correo al cliente después de guardar todo.
    // Si el correo falla, el ticket igual queda creado.
    $correoEnviado = false;
    $errorCorreo = "";

    if (!empty($correoCliente)) {
        $resultadoCorreo = enviarCorreoTicketCreado(
            $correoCliente,
            $nombreCliente,
            $codigoTicket,
            $tipoServicioFinal,
            $descripcion,
            $montoBase
        );

        if ($resultadoCorreo === true) {
            $correoEnviado = true;
        } else {
            $errorCorreo = $resultadoCorreo;
        }
    }

    echo json_encode([
        "success" => true,
        "message" => "Ticket creado correctamente.",
        "correo_enviado" => $correoEnviado,
        "error_correo" => $errorCorreo,
        "ticket" => [
            "id_ticket" => $idTicket,
            "codigo" => $codigoTicket,
            "titulo" => $titulo,
            "servicio" => $tipoServicioFinal,
            "descripcion" => $descripcion,
            "estado" => $estado,
            "prioridad" => $prioridad,
            "monto" => $montoBase,
            "cliente" => $nombreCliente
        ]
    ]);

} catch (Exception $e) {
    $conexion->rollback();

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "No se pudo crear el ticket.",
        "error" => $e->getMessage()
    ]);
}
?>