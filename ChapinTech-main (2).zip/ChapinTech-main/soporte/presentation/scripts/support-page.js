document.addEventListener('DOMContentLoaded', () => {
  const menuButton = document.querySelector('.support-menu-btn');
  const navLinks = document.querySelector('.support-shell .nav-links');
  const ticketSearchForm = document.querySelector('.ticket-search-form');
  const ticketResult = document.getElementById('ticketResult');
  const roleButtons = document.querySelectorAll('.role-chip[data-role]');
  const rolePanels = document.querySelectorAll('[data-role-panel]');
  const clientToggleButtons = document.querySelectorAll('.client-toggle-btn[data-client-panel]');
  const clientContents = document.querySelectorAll('[data-client-content]');
  const statusSteps = ['Recibido', 'Asignado', 'Tecnico en Ruta', 'Diagnostico', 'En Reparacion', 'Finalizado'];
  const technicianModal = document.getElementById('technicianModal');
  let activeAssignButton = null;

  const demoTickets = [
    {
      code: 'CT-1024',
      contact: 'carlos@email.com',
      client: 'Carlos Mendez',
      service: 'Reparacion de laptop',
      status: 'En Reparacion',
      technician: 'Anna',
      priority: 'Alta',
      steps: ['Recibido', 'Asignado', 'Tecnico en Ruta', 'Diagnostico', 'En Reparacion']
    },
    {
      code: 'CT-1025',
      contact: '+50248882299',
      client: 'Maria Lopez',
      service: 'Soporte de impresora',
      status: 'Tecnico en ruta',
      technician: 'Kevin',
      priority: 'Media',
      steps: ['Recibido', 'Asignado', 'Tecnico en Ruta']
    }
  ];
  // ========================================
  // SELECT DE SERVICIOS CON IMAGEN Y PRECIO
  // ========================================

  const servicioSelect = document.getElementById("servicio");
  const servicePreviewBg = document.getElementById("servicePreviewBg");
  const serviceTitle = document.getElementById("serviceTitle");
  const servicePrice = document.getElementById("servicePrice");
  const serviceDesc = document.getElementById("serviceDesc");
  const serviceTags = document.getElementById("serviceTags");

  function actualizarVistaServicio() {
    if (
      !servicioSelect ||
      !servicePreviewBg ||
      !serviceTitle ||
      !servicePrice ||
      !serviceDesc ||
      !serviceTags
    ) {
      return;
    }

    const selectedOption = servicioSelect.options[servicioSelect.selectedIndex];

    const title = selectedOption.dataset.title || "Servicio";
    const price = selectedOption.dataset.price || "Q0";
    const desc = selectedOption.dataset.desc || "Selecciona un servicio para ver más información.";
    const bg = selectedOption.dataset.bg || "";
    const tags = selectedOption.dataset.tags
      ? selectedOption.dataset.tags.split(",")
      : [];

    serviceTitle.textContent = title;
    servicePrice.textContent = price;
    serviceDesc.textContent = desc;

    if (bg) {
      servicePreviewBg.style.backgroundImage = `url('${bg}')`;
    }

    serviceTags.innerHTML = "";

    tags.forEach((tag) => {
      const span = document.createElement("span");
      span.textContent = tag.trim();
      serviceTags.appendChild(span);
    });
  }

  if (servicioSelect) {
    servicioSelect.addEventListener("change", actualizarVistaServicio);
    actualizarVistaServicio();
  }
// ========================================
// CREAR TICKET REAL EN MYSQL
// ========================================

const crearTicketBtn = document.getElementById("crearTicketBtn");
const ticketCreado = document.getElementById("ticketCreado");
const descripcionProblema = document.getElementById("descripcionProblema");

// Esta función evita que texto raro o código HTML se pinte directo en pantalla.
function limpiarTexto(texto) {
  const div = document.createElement("div");
  div.textContent = texto;
  return div.innerHTML;
}

if (crearTicketBtn && ticketCreado && servicioSelect) {
  crearTicketBtn.addEventListener("click", async () => {
    const selectedOption = servicioSelect.options[servicioSelect.selectedIndex];

    const servicio = selectedOption.dataset.title || "";
    const idTarifa = selectedOption.dataset.tarifaId || "";
    const descripcion = descripcionProblema ? descripcionProblema.value.trim() : "";

    if (!descripcion) {
      ticketCreado.classList.add("show");

      ticketCreado.innerHTML = `
        <h4>Falta la descripción</h4>
        <p>Describe brevemente el problema para poder crear el ticket.</p>
      `;

      return;
    }

    crearTicketBtn.disabled = true;
    crearTicketBtn.innerHTML = `<span>Creando ticket...</span>`;

    const formData = new FormData();

    formData.append("tipo_servicio", servicio);
    formData.append("descripcion", descripcion);
    formData.append("id_tarifa", idTarifa);

try {
  const response = await fetch("crear_ticket.php", {
    method: "POST",
    body: formData
  });

  const data = await response.json();
  console.log("Respuesta crear ticket:", data);
  if (!data.success) {
    throw new Error(data.message || "No se pudo crear el ticket.");
  }


  const ticket = data.ticket;

  ticketCreado.classList.add("show");

ticketCreado.innerHTML = `
  <h4>Ticket creado correctamente</h4>
  <p>Tu solicitud fue registrada en el sistema.</p>
  <p><strong>Servicio:</strong> ${limpiarTexto(ticket.servicio)}</p>
  <p><strong>Precio base:</strong> Q${Number(ticket.monto).toFixed(2)}</p>
  <p><strong>Estado:</strong> ${limpiarTexto(ticket.estado)}</p>
  <p><strong>Descripción:</strong> ${limpiarTexto(ticket.descripcion)}</p>
  <p><strong>Correo enviado:</strong> ${data.correo_enviado ? "Sí" : "No"}</p>
  ${data.error_correo ? `<p><strong>Error correo:</strong> ${limpiarTexto(data.error_correo)}</p>` : ""}
  <span class="ticket-code">${limpiarTexto(ticket.codigo)}</span>
`;

  descripcionProblema.value = "";
} catch (error) {
  ticketCreado.classList.add("show");

  ticketCreado.innerHTML = `
    <h4>No se pudo crear el ticket</h4>
    <p>${limpiarTexto(error.message)}</p>
  `;
} finally {
  crearTicketBtn.disabled = false;
  crearTicketBtn.innerHTML = `<span>Crear ticket</span>`;
}
  });
}

  if (!ticketSearchForm || !ticketResult) {
    return;
  }

  function setRoleView(role) {
    roleButtons.forEach((button) => {
      const isActive = button.dataset.role === role;
      button.classList.toggle('active', isActive);
      button.setAttribute('aria-selected', String(isActive));
    });

    rolePanels.forEach((panel) => {
      panel.classList.toggle('is-collapsed', panel.dataset.rolePanel !== role);
    });
  }

  function setClientPanel(panelName) {
    clientToggleButtons.forEach((button) => {
      const isActive = button.dataset.clientPanel === panelName;
      button.classList.toggle('active', isActive);
      button.setAttribute('aria-expanded', String(isActive));
    });

    clientContents.forEach((content) => {
      content.classList.toggle('is-collapsed', content.dataset.clientContent !== panelName);
    });
  }

  function renderStatusBar(activeSteps, size = 'default') {
    const lastActiveIndex = Math.max(...activeSteps.map((step) => statusSteps.indexOf(step)));
    const progress = lastActiveIndex <= 0
      ? 0
      : (lastActiveIndex / (statusSteps.length - 1)) * 100;
    const sizeClass = size === 'compact' || size === 'client' ? size : '';

    return `
      <div class="status-progress ${sizeClass}">
        <div class="status-track">
          <div class="status-fill" style="width:${progress}%; --progress:${progress}%;"></div>
          ${statusSteps.map((step, index) => {
            const isDone = index <= lastActiveIndex ? 'done' : '';
            const isCurrent = index === lastActiveIndex ? 'current' : '';

            return `
              <div class="status-point ${isDone} ${isCurrent}">
                <span></span>
                <p>${step}</p>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }

  function openTechnicianModal(assignButton) {
    activeAssignButton = assignButton;
    technicianModal.classList.remove('is-collapsed');
    technicianModal.setAttribute('aria-hidden', 'false');
  }

  function closeTechnicianModal() {
    technicianModal.classList.add('is-collapsed');
    technicianModal.setAttribute('aria-hidden', 'true');
    activeAssignButton = null;
  }

  roleButtons.forEach((button) => {
    button.addEventListener('click', () => {
      setRoleView(button.dataset.role);
    });
  });

  clientToggleButtons.forEach((button) => {
    button.addEventListener('click', () => {
      setClientPanel(button.dataset.clientPanel);
    });
  });

  document.querySelectorAll('.assign-tech-btn').forEach((button) => {
    button.addEventListener('click', () => {
      openTechnicianModal(button);
    });
  });

  document.querySelectorAll('[data-close-modal]').forEach((button) => {
    button.addEventListener('click', closeTechnicianModal);
  });

  document.querySelectorAll('.technician-option').forEach((button) => {
    button.addEventListener('click', () => {
      if (!activeAssignButton) {
        return;
      }

      activeAssignButton.textContent = button.dataset.technician;
      activeAssignButton.classList.remove('assign-tech-btn');
      activeAssignButton.classList.add('assigned-tech-btn');
      closeTechnicianModal();
    });
  });

  setRoleView('client');
  setClientPanel('search');

  ticketSearchForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const codeInput = ticketSearchForm.querySelector('#ticketCode');
    const code = codeInput.value.trim().toUpperCase();

    const ticket = demoTickets.find((item) => {
      return item.code === code;
    });

    if (!ticket) {
      ticketResult.classList.remove('is-collapsed');
      ticketResult.innerHTML = `
        <div class="ticket-result-error">
          <span>!</span>
          <h3>Numero incorrecto o inexistente</h3>
          <p>No encontramos un ticket con ese codigo. Verifica el numero e intenta nuevamente.</p>
        </div>
      `;
      return;
    }

    ticketResult.classList.remove('is-collapsed');
    ticketResult.innerHTML = `
      <div class="ticket-result-live">
        <div class="module-heading">
          <div>
            <p>Ticket encontrado</p>
            <h2>${ticket.code}</h2>
          </div>
          <span class="module-badge">${ticket.status}</span>
        </div>

        <div class="ticket-meta-grid">
          <div class="ticket-meta">
            <p>Cliente</p>
            <strong>${ticket.client}</strong>
          </div>
          <div class="ticket-meta">
            <p>Tecnico</p>
            <strong>${ticket.technician}</strong>
          </div>
          <div class="ticket-meta">
            <p>Servicio</p>
            <strong>${ticket.service}</strong>
          </div>
          <div class="ticket-meta">
            <p>Prioridad</p>
            <strong>${ticket.priority}</strong>
          </div>
        </div>

        ${renderStatusBar(ticket.steps, 'client')}
      </div>
    `;
  });

  document.querySelectorAll('.admin-ticket-row[data-steps]').forEach((row) => {
    const activeSteps = row.dataset.steps.split(',').map((step) => step.trim());
    const progressTarget = row.querySelector('.admin-ticket-progress');

    if (progressTarget) {
      progressTarget.innerHTML = renderStatusBar(activeSteps, 'compact');
    }
  });
});
