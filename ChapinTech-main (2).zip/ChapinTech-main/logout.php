<?php
session_start();

/* LIMPIAR VARIABLES */
$_SESSION = [];

/* DESTRUIR SESIÓN */
session_unset();
session_destroy();

/* REDIRIGIR */
header("Location: auth_sys/views/login.php");
exit();
?>