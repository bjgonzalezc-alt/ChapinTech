<?php
session_start();

if(!isset($_SESSION['usuario_id'])){
    header("Location: views/login.php");
    exit();
}

if($_SESSION['nivel_acceso'] < 80){
    header("Location: ../index.html");
    exit();
}

// Evita cache raro del navegador
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include 'admin.html';
?>