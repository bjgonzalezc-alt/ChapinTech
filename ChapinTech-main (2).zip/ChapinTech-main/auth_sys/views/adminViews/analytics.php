<?php
session_start();
if (!isset($_SESSION['nivel_acceso']) || $_SESSION['nivel_acceso'] < 80) { header("Location: login.php"); exit(); }
require_once __DIR__ . '/../../libs/config/database.php';
$conn = AuthDatabase::getInstance();

// 1. Tickets generados en los últimos 7 días
$queryDias = "SELECT DATE(fecha_creacion) as fecha, COUNT(*) as total FROM ticket WHERE fecha_creacion >= DATE(NOW()) - INTERVAL 7 DAY GROUP BY DATE(fecha_creacion) ORDER BY fecha ASC";
$datosDias = $conn->query($queryDias)->fetchAll(PDO::FETCH_ASSOC);

$fechas = [];
$totales = [];
foreach($datosDias as $d) {
    $fechas[] = date("d/m", strtotime($d['fecha']));
    $totales[] = $d['total'];
}

// 2. Distribución de tickets por estado actual
$queryEstados = "SELECT estado, COUNT(*) as total FROM ticket GROUP BY estado";
$datosEstados = $conn->query($queryEstados)->fetchAll(PDO::FETCH_ASSOC);

$estados = [];
$totalesEstados = [];
foreach($datosEstados as $e) {
    $estados[] = ucfirst(str_replace('_', ' ', $e['estado']));
    $totalesEstados[] = $e['total'];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>ChapinTech | Analytics</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background: #020617; color: white; margin: 0; padding: 20px; }
        .container { max-width: 1200px; margin: 20px auto; background: rgba(255,255,255,.03); border: 1px solid rgba(99,230,255,.12); border-radius: 24px; padding: 40px; box-shadow: 0 0 50px rgba(34,211,238,.05); backdrop-filter: blur(18px); }
        .btn-back { display: inline-block; color: #63e6ff; text-decoration: none; font-weight: 600; padding: 8px 16px; border-radius: 8px; background: rgba(99,230,255,.1); border: 1px solid rgba(99,230,255,.2); margin-bottom: 20px; transition: 0.3s; }
        .btn-back:hover { background: rgba(99,230,255,.2); transform: translateX(-5px); }
        .charts-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-top: 30px; }
        .chart-box { background: #07111f; border: 1px solid rgba(255,255,255,.08); border-radius: 16px; padding: 20px; }
        @media (max-width: 768px) { .charts-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
<div class="container">
    <a href="/ChapinTech-main/auth_sys/admin.php" class="btn-back">← Volver al Panel Admin</a>
    <h2 style="font-family: 'Orbitron'; color: #63e6ff;">Métricas y Analytics</h2>
    <p style="color: rgba(255,255,255,.5);">Rendimiento del sistema en tiempo real.</p>
    
    <div class="charts-grid">
        <div class="chart-box">
            <h4 style="text-align: center; color: #fff;">Volumen de Tickets (Últimos 7 días)</h4>
            <canvas id="lineChart"></canvas>
        </div>
        <div class="chart-box">
            <h4 style="text-align: center; color: #fff;">Distribución por Estado</h4>
            <canvas id="pieChart"></canvas>
        </div>
    </div>
</div>

<script>
// Pasar datos de PHP a variables de JavaScript
const fechas = <?= json_encode($fechas) ?>;
const totalesDias = <?= json_encode($totales) ?>;
const estados = <?= json_encode($estados) ?>;
const totalesEstados = <?= json_encode($totalesEstados) ?>;

// Configuración global de colores para Chart.js
Chart.defaults.color = 'rgba(255, 255, 255, 0.7)';
Chart.defaults.borderColor = 'rgba(255, 255, 255, 0.1)';

// Gráfico de Línea
new Chart(document.getElementById('lineChart'), {
    type: 'line',
    data: {
        labels: fechas,
        datasets: [{
            label: 'Tickets Creados',
            data: totalesDias,
            borderColor: '#63e6ff',
            backgroundColor: 'rgba(99, 230, 255, 0.2)',
            tension: 0.4,
            fill: true
        }]
    }
});

// Gráfico de Pastel (Doughnut)
new Chart(document.getElementById('pieChart'), {
    type: 'doughnut',
    data: {
        labels: estados,
        datasets: [{
            data: totalesEstados,
            backgroundColor: [
                '#63e6ff', // Cyan
                '#8b5cf6', // Violet
                '#3ba7ff', // Blue
                '#ffc107', // Yellow
                '#00ff80'  // Green
            ],
            borderWidth: 0
        }]
    }
});
</script>
</body>
</html>