<?php
session_start();
if (!isset($_SESSION['nivel_acceso']) || $_SESSION['nivel_acceso'] < 80) {
    header("Location: login.php");
    exit();
}
require_once __DIR__ . '/../../libs/config/database.php';
$conn = AuthDatabase::getInstance();

// Consultar técnicos y contar cuántos tickets activos tienen asignados
$query = "
    SELECT u.nombre, u.email, u.telefono, t.especialidad, t.estado_disponibilidad, t.calificacion_promedio,
           (SELECT COUNT(*) FROM ticket WHERE id_tecnico = t.id_tecnico AND estado NOT IN ('cerrado', 'cancelado')) AS tickets_activos
    FROM tecnico t
    JOIN usuario u ON t.id_usuario = u.id_usuario
    WHERE u.activo = 1
";
$tecnicos = $conn->query($query)->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>ChapinTech | Gestión de Técnicos</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #020617; color: white; margin: 0; padding: 20px; }
        .container { max-width: 1200px; margin: 20px auto; background: rgba(255,255,255,.03); border: 1px solid rgba(99,230,255,.12); border-radius: 24px; padding: 40px; box-shadow: 0 0 50px rgba(34,211,238,.05); backdrop-filter: blur(18px); }
        .btn-back { display: inline-block; color: #63e6ff; text-decoration: none; font-weight: 600; padding: 8px 16px; border-radius: 8px; background: rgba(99,230,255,.1); border: 1px solid rgba(99,230,255,.2); margin-bottom: 20px; transition: 0.3s; }
        .btn-back:hover { background: rgba(99,230,255,.2); transform: translateX(-5px); }
        .tech-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; margin-top: 20px; }
        .tech-card { background: #07111f; border: 1px solid rgba(255,255,255,.08); border-radius: 16px; padding: 20px; transition: 0.3s; }
        .tech-card:hover { border-color: #63e6ff; box-shadow: 0 0 20px rgba(99,230,255,.1); transform: translateY(-3px); }
        .tech-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px; }
        .tech-name { font-family: 'Orbitron', sans-serif; color: #63e6ff; font-size: 1.1rem; margin: 0 0 5px 0; }
        .tech-spec { color: rgba(255,255,255,.5); font-size: 0.85rem; margin: 0; }
        .badge { padding: 4px 10px; border-radius: 999px; font-size: 0.75rem; font-weight: bold; }
        .b-disponible { background: rgba(0, 255, 128, 0.2); color: #00ff80; }
        .b-ocupado { background: rgba(255, 193, 7, 0.2); color: #ffc107; }
        .tech-stats { display: flex; justify-content: space-between; margin-top: 20px; padding-top: 15px; border-top: 1px solid rgba(255,255,255,.05); }
        .stat { text-align: center; }
        .stat-val { display: block; font-size: 1.2rem; font-weight: bold; color: white; }
        .stat-lbl { font-size: 0.75rem; color: rgba(255,255,255,.5); }
    </style>
</head>
<body>
<div class="container">
    <a href="../../admin.php"class="btn-back">← Volver al Panel Admin</a>
    <h2 style="font-family: 'Orbitron'; color: #63e6ff;">Fuerza Operativa Técnica</h2>
    
    <div class="tech-grid">
        <?php if(empty($tecnicos)): ?>
            <p style="color: rgba(255,255,255,.5);">No hay técnicos registrados en la base de datos.</p>
        <?php else: ?>
            <?php foreach($tecnicos as $t): 
                $estadoClase = ($t['estado_disponibilidad'] == 'disponible') ? 'b-disponible' : 'b-ocupado';
            ?>
            <div class="tech-card">
                <div class="tech-header">
                    <div>
                        <h3 class="tech-name"><?= htmlspecialchars($t['nombre']) ?></h3>
                        <p class="tech-spec"><?= htmlspecialchars($t['especialidad']) ?></p>
                    </div>
                    <span class="badge <?= $estadoClase ?>"><?= strtoupper($t['estado_disponibilidad']) ?></span>
                </div>
                <div style="font-size: 0.85rem; color: rgba(255,255,255,.7);">
                    📞 <?= htmlspecialchars($t['telefono'] ?? 'N/A') ?><br>
                    ✉️ <?= htmlspecialchars($t['email']) ?>
                </div>
                <div class="tech-stats">
                    <div class="stat">
                        <span class="stat-val"><?= $t['tickets_activos'] ?></span>
                        <span class="stat-lbl">En Curso</span>
                    </div>
                    <div class="stat">
                        <span class="stat-val"><?= number_format($t['calificacion_promedio'], 1) ?> ★</span>
                        <span class="stat-lbl">Rating</span>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
</body>
</html>