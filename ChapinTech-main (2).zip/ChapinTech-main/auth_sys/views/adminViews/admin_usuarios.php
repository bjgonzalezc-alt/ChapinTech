<?php
// auth_sys/views/admin_usuarios.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Validación de seguridad
if (!isset($_SESSION['nivel_acceso']) || $_SESSION['nivel_acceso'] < 80) {
    header("Location: login.php");
    exit();
}

require_once __DIR__ . '/../../controllers/UserController.php';
$controller = new UserController();
$usuarios = $controller->listarUsuarios();

$nivelLogueado = $_SESSION['nivel_acceso'];
$rolLogueado = $_SESSION['usuario_rol'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChapinTech | Control de Usuarios</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Estilos base */
        body {
            font-family: 'Inter', sans-serif;
            background: #020617;
            color: white;
            margin: 0;
            padding: 20px;
            background-image: radial-gradient(circle at 50% 20%, rgba(99,230,255,.05), transparent 50%);
        }
        .container {
            max-width: 1200px;
            margin: 40px auto;
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(99,230,255,.12);
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 0 50px rgba(34,211,238,.05);
            backdrop-filter: blur(18px);
        }
        
        /* Controles Superiores (Botón Volver, Header) */
        .top-nav {
            margin-bottom: 20px;
        }
        .btn-back {
            display: inline-block;
            color: #63e6ff;
            text-decoration: none;
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 8px;
            background: rgba(99,230,255,.1);
            border: 1px solid rgba(99,230,255,.2);
            transition: 0.3s;
        }
        .btn-back:hover {
            background: rgba(99,230,255,.2);
            transform: translateX(-5px);
        }

        .header-panel {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid rgba(255,255,255,.08);
            padding-bottom: 20px;
            margin-bottom: 20px;
        }
        h2 { font-family: 'Orbitron', sans-serif; color: #63e6ff; margin: 0; }
        .user-badge {
            background: rgba(99,230,255,.12);
            border: 1px solid rgba(99,230,255,.3);
            color: #63e6ff;
            padding: 8px 16px;
            border-radius: 999px;
            font-size: 0.85rem;
            font-weight: bold;
        }

        /* Barra de Herramientas (Filtros y Búsqueda) */
        .toolbar {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }
        .toolbar input, .toolbar select {
            padding: 12px 18px;
            border-radius: 12px;
            background: #07111f;
            color: white;
            border: 1px solid rgba(99,230,255,.2);
            outline: none;
            font-size: 0.95rem;
            font-family: 'Inter', sans-serif;
            transition: 0.3s;
        }
        .toolbar input { flex-grow: 1; min-width: 250px; }
        .toolbar input:focus, .toolbar select:focus { border-color: #63e6ff; box-shadow: 0 0 15px rgba(99,230,255,.15); }

        /* Mensajes */
        .alert { padding: 15px; border-radius: 12px; margin-bottom: 25px; font-size: 0.9rem; text-align: center; }
        .alert-success { background: rgba(0, 255, 128, 0.1); color: #00ff80; border: 1px solid rgba(0, 255, 128, 0.3); }
        .alert-error { background: rgba(255, 77, 77, 0.1); color: #ff4d4d; border: 1px solid rgba(255, 77, 77, 0.3); }
        
        /* Tabla y Ordenamiento */
        table { width: 100%; border-collapse: collapse; }
        th {
            font-family: 'Orbitron', sans-serif;
            color: rgba(255,255,255,.6);
            text-align: left;
            padding: 15px;
            font-size: 0.85rem;
            letter-spacing: 1px;
            border-bottom: 2px solid rgba(255,255,255,.08);
            user-select: none;
        }
        /* Estilos para encabezados ordenables */
        th.sortable {
            cursor: pointer;
            transition: color 0.2s;
        }
        th.sortable:hover { color: #63e6ff; }
        .sort-icon { margin-left: 5px; font-size: 0.8rem; color: #63e6ff; }

        td { padding: 15px; border-bottom: 1px solid rgba(255,255,255,.05); font-size: 0.95rem; }
        tr:hover td { background: rgba(255,255,255,.01); }
        
        /* Botones y Selects de la tabla */
        select.role-select {
            padding: 8px 12px;
            border-radius: 8px;
            background: #07111f;
            color: white;
            border: 1px solid rgba(99,230,255,.2);
            outline: none;
            cursor: pointer;
        }
        .btn { padding: 8px 14px; border: none; border-radius: 8px; font-weight: bold; font-size: 0.85rem; cursor: pointer; transition: 0.2s; }
        .btn-danger { background: rgba(255, 77, 77, 0.15); color: #ff4d4d; border: 1px solid rgba(255, 77, 77, 0.4); }
        .btn-danger:hover:not(:disabled) { background: #ff4d4d; color: black; box-shadow: 0 0 15px rgba(255,77,77,0.4); }
        .btn:disabled { opacity: 0.2; cursor: not-allowed; }
        .action-form { display: inline-block; margin: 0; }
        .hidden-row { display: none !important; }
    </style>
</head>
<body>

<div class="container">
    
    <div class="top-nav">
        <a href="../../admin.html" class="btn-back">← Volver al Panel Admin</a>
    </div>

    <div class="header-panel">
        <div>
            <h2>Panel de Control RBAC</h2>
            <p style="color: rgba(255,255,255,.5); margin: 5px 0 0 0; font-size: 0.9rem;">
                Supervisión del Sistema Operativo Técnico e identidades.
            </p>
        </div>
        <div class="user-badge">
            Operador: <?= htmlspecialchars($_SESSION['usuario_nombre']) ?> (<?= htmlspecialchars(ucfirst($rolLogueado)) ?>)
        </div>
    </div>

    <div class="toolbar">
        <input type="text" id="searchInput" placeholder="Buscar por nombre o correo electrónico...">
        
        <select id="roleFilter">
            <option value="todos">Todos los roles</option>
            <option value="administrador">Administradores</option>
            <option value="soporte">Soporte</option>
            <option value="tecnico">Técnicos</option>
            <option value="cliente">Clientes</option>
        </select>
    </div>

    <?php if (isset($_SESSION['mensaje_gestion'])): ?>
        <div class="alert alert-success"><?= $_SESSION['mensaje_gestion']; unset($_SESSION['mensaje_gestion']); ?></div>
    <?php endif; ?>
    <?php if (isset($_SESSION['error_gestion'])): ?>
        <div class="alert alert-error"><?= $_SESSION['error_gestion']; unset($_SESSION['error_gestion']); ?></div>
    <?php endif; ?>

    <table id="usersTable">
        <thead>
            <tr>
                <th class="sortable" data-sort="nombre">Usuario / Operario <span class="sort-icon">⇅</span></th>
                <th>Correo Electrónico</th>
                <th class="sortable" data-sort="fecha">Fecha de Alta <span class="sort-icon">⇅</span></th>
                <th>Nivel / Permisos</th>
                <th>Acción Operativa</th>
            </tr>
        </thead>
        <tbody id="tableBody">
            <?php foreach ($usuarios as $usr): 
                $rolTarget = strtolower($usr['tipo']);
                
                $pesoTarget = 10;
                if ($rolTarget === 'administrador') $pesoTarget = 100;
                elseif ($rolTarget === 'soporte') $pesoTarget = 80;
                elseif ($rolTarget === 'tecnico') $pesoTarget = 50;

                $puedeModificarRol = ($nivelLogueado == 100 || ($nivelLogueado == 80 && $rolTarget !== 'administrador'));
                $puedeEliminar = ($nivelLogueado == 100 || ($nivelLogueado == 80 && $pesoTarget < 80)) && ($usr['id_usuario'] != $_SESSION['usuario_id']);
            ?>
            <tr class="user-row" 
                data-nombre="<?= htmlspecialchars(strtolower($usr['nombre'])) ?>" 
                data-email="<?= htmlspecialchars(strtolower($usr['email'])) ?>" 
                data-rol="<?= $rolTarget ?>" 
                data-fecha="<?= strtotime($usr['fecha_registro']) ?>">
                
                <td><?= htmlspecialchars($usr['nombre']) ?></td>
                <td><?= htmlspecialchars($usr['email']) ?></td>
                <td><?= htmlspecialchars(date("d/m/Y H:i", strtotime($usr['fecha_registro']))) ?></td>
                <td>
                    <form action="../../controllers/UserController.php" method="POST" class="action-form">
                        <input type="hidden" name="action" value="update_role">
                        <input type="hidden" name="id_usuario" value="<?= $usr['id_usuario'] ?>">
                        
                        <select name="nuevo_rol" class="role-select" onchange="this.form.submit()" <?= !$puedeModificarRol ? 'disabled' : '' ?>>
                            <option value="cliente" <?= $rolTarget === 'cliente' ? 'selected' : '' ?>>Cliente</option>
                            <option value="tecnico" <?= $rolTarget === 'tecnico' ? 'selected' : '' ?>>Técnico</option>
                            <option value="soporte" <?= $rolTarget === 'soporte' ? 'selected' : '' ?>>Soporte</option>
                            <option value="administrador" <?= $rolTarget === 'administrador' ? 'selected' : '' ?> <?= $nivelLogueado < 100 ? 'disabled' : '' ?>>Administrador</option>
                        </select>
                    </form>
                </td>
                <td>
                    <form action="../../controllers/UserController.php" method="POST" class="action-form" onsubmit="return confirm('¿Confirmas la remoción permanente de este registro?');">
                        <input type="hidden" name="action" value="delete_user">
                        <input type="hidden" name="id_usuario" value="<?= $usr['id_usuario'] ?>">
                        <button type="submit" class="btn btn-danger" <?= !$puedeEliminar ? 'disabled' : '' ?>>Eliminar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('searchInput');
    const roleFilter = document.getElementById('roleFilter');
    const tableBody = document.getElementById('tableBody');
    const rows = Array.from(tableBody.getElementsByClassName('user-row'));
    const sortableHeaders = document.querySelectorAll('.sortable');

    // Estado actual de ordenamiento
    let currentSort = { column: null, order: 'asc' };

    // FUNCIÓN DE FILTRADO (Búsqueda y Rol combinados)
    function filterTable() {
        const searchTerm = searchInput.value.toLowerCase().trim();
        const roleTerm = roleFilter.value;

        rows.forEach(row => {
            const nombre = row.getAttribute('data-nombre');
            const email = row.getAttribute('data-email');
            const rol = row.getAttribute('data-rol');

            const coincideBusqueda = nombre.includes(searchTerm) || email.includes(searchTerm);
            const coincideRol = (roleTerm === 'todos') || (rol === roleTerm);

            if (coincideBusqueda && coincideRol) {
                row.classList.remove('hidden-row');
            } else {
                row.classList.add('hidden-row');
            }
        });
    }

    // Eventos para ejecutar el filtrado al escribir o cambiar el select
    searchInput.addEventListener('input', filterTable);
    roleFilter.addEventListener('change', filterTable);

    // FUNCIÓN DE ORDENAMIENTO (Alfabeto y Fecha)
    sortableHeaders.forEach(header => {
        header.addEventListener('click', () => {
            const sortType = header.getAttribute('data-sort'); // 'nombre' o 'fecha'

            // Alternar orden si es la misma columna, o reiniciar a 'asc' si es nueva
            if (currentSort.column === sortType) {
                currentSort.order = currentSort.order === 'asc' ? 'desc' : 'asc';
            } else {
                currentSort.column = sortType;
                currentSort.order = 'asc';
            }

            // Actualizar los iconos de las flechas (⇅, ↑, ↓)
            sortableHeaders.forEach(th => th.querySelector('.sort-icon').textContent = '⇅');
            header.querySelector('.sort-icon').textContent = currentSort.order === 'asc' ? '↑' : '↓';

            // Ordenar el array de filas
            rows.sort((a, b) => {
                let valA = a.getAttribute(`data-${sortType}`);
                let valB = b.getAttribute(`data-${sortType}`);

                // Si estamos ordenando por fecha, necesitamos comparar números (timestamps), no textos
                if (sortType === 'fecha') {
                    valA = parseInt(valA);
                    valB = parseInt(valB);
                }

                if (valA < valB) return currentSort.order === 'asc' ? -1 : 1;
                if (valA > valB) return currentSort.order === 'asc' ? 1 : -1;
                return 0;
            });

            // Re-insertar las filas en el tbody ya ordenadas (el DOM las moverá automáticamente de posición)
            rows.forEach(row => tableBody.appendChild(row));
        });
    });
});
</script>

</body>
</html>