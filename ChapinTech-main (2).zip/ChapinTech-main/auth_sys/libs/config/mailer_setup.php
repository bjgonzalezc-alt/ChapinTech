

¿<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require_once __DIR__ . '/../PHPMailer/src/Exception.php';
require_once __DIR__ . '/../PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../PHPMailer/src/SMTP.php';

function configurarMailer() {
    $mail = new PHPMailer(true);

    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;

    $mail->Username   = 'bennygonza2004@gmail.com';
    $mail->Password   = 'zmnu bxnj wwyt mbmt';

    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    $mail->CharSet = 'UTF-8';

    return $mail;
}

function enviarCorreoOTP($correoDestino, $codigoOTP, $nombreUsuario) {

    try {
        $mail = configurarMailer();

        $mail->setFrom('bennygonza2004@gmail.com', 'ChapinTech Auth');
        $mail->addAddress($correoDestino, $nombreUsuario);

        $mail->isHTML(true);

        $mail->Subject = 'Verifica tu cuenta - Código OTP';

        $mail->Body = "
            <h2>¡Hola, {$nombreUsuario}!</h2>
            <p>Gracias por registrarte.</p>
            <p>Tu código OTP es:</p>

            <h1 style='color:#3ba7ff; letter-spacing:5px;'>
                {$codigoOTP}
            </h1>

            <p>Este código expirará en 15 minutos.</p>
        ";

        $mail->send();

        return true;

    } catch (Exception $e) {
        return "Error al enviar OTP: {$mail->ErrorInfo}";
    }
}

function enviarCorreoTicketCreado(
    $correoDestino,
    $nombreUsuario,
    $codigoTicket,
    $servicio,
    $descripcion,
    $montoBase
) {

    try {

        $mail = configurarMailer();

        $mail->setFrom('bennygonza2004@gmail.com', 'ChapinTech Soporte');

        $mail->addAddress($correoDestino, $nombreUsuario);

        $mail->isHTML(true);

        $mail->Subject = "Ticket creado correctamente - {$codigoTicket}";

        $mail->Body = "
            <h2>Hola {$nombreUsuario}</h2>

            <p>Tu ticket fue creado correctamente.</p>

            <p><strong>Código:</strong> {$codigoTicket}</p>
            <p><strong>Servicio:</strong> {$servicio}</p>
            <p><strong>Descripción:</strong> {$descripcion}</p>
            <p><strong>Precio base:</strong> Q" . number_format($montoBase, 2) . "</p>
            <p><strong>Estado:</strong> Abierto</p>
        ";

        $mail->send();

        return true;

    } catch (Exception $e) {
        return "Error al enviar correo de ticket: {$mail->ErrorInfo}";
    }
}