<?php
// auth_sys/controllers/api_dashboard.php
session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../libs/config/database.php';
$conn = AuthDatabase::getInstance();

try {
    $data = ['kpis' => [], 'casos' => []];
    
    // 1. KPI: Tickets Activos (Pendientes o Asignados)
    $stmt = $conn->query("SELECT COUNT(*) FROM ticket WHERE estado IN ('pendiente', 'asignado')");
    $data['kpis']['activos'] = $stmt->fetchColumn();

    // 2. KPI: En Proceso (En camino, en proceso, pdte pago)
    $stmt = $conn->query("SELECT COUNT(*) FROM ticket WHERE estado IN ('en_camino', 'en_proceso', 'finalizado_pendiente_pago')");
    $data['kpis']['proceso'] = $stmt->fetchColumn();

    // 3. KPI: Técnicos Operativos (Usuarios activos que son técnicos)
    $stmt = $conn->query("SELECT COUNT(*) FROM tecnico t JOIN usuario u ON t.id_usuario = u.id_usuario WHERE u.activo = 1");
    $data['kpis']['tecnicos'] = $stmt->fetchColumn();

    // 4. KPI: Completados Hoy
    $stmt = $conn->query("SELECT COUNT(*) FROM ticket WHERE estado = 'cerrado' AND DATE(fecha_cierre) = CURDATE()");
    $data['kpis']['completados_hoy'] = $stmt->fetchColumn();

    // 5. Casos Esperando Asignación (Solo los pendientes)
    $stmt = $conn->query("
        SELECT t.id_ticket, t.prioridad, t.descripcion, c.direccion, u.nombre AS cliente_nombre 
        FROM ticket t
        JOIN cliente c ON t.id_cliente = c.id_cliente
        JOIN usuario u ON c.id_usuario = u.id_usuario
        WHERE t.estado = 'pendiente'
        ORDER BY FIELD(t.prioridad, 'alta', 'media', 'baja'), t.fecha_creacion ASC
    ");
    $data['casos'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'data' => $data]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>