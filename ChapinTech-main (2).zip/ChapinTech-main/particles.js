const particleCanvas = document.getElementById("particles");
const particleCtx = particleCanvas.getContext("2d");
const hero = document.querySelector(".hero");

let particles = [];
let mouse = { x: null, y: null };

function resizeParticlesCanvas() {
  if (!hero || !particleCanvas) return;

  const rect = hero.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;

  particleCanvas.width = rect.width * dpr;
  particleCanvas.height = rect.height * dpr;

  particleCanvas.style.width = rect.width + "px";
  particleCanvas.style.height = rect.height + "px";

  particleCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

class Particle {
  constructor() {
    const rect = hero.getBoundingClientRect();

    this.x = Math.random() * rect.width;
    this.y = Math.random() * rect.height;
    this.vx = (Math.random() - 0.5) * 0.35;
    this.vy = (Math.random() - 0.5) * 0.35;
    this.size = Math.random() * 1.8 + 0.7;
  }

  update() {
    const rect = hero.getBoundingClientRect();

    this.x += this.vx;
    this.y += this.vy;

    if (mouse.x !== null && mouse.y !== null) {
      const dx = mouse.x - this.x;
      const dy = mouse.y - this.y;
      const distance = Math.sqrt(dx * dx + dy * dy);

      if (distance < 160) {
        this.x += dx * 0.008;
        this.y += dy * 0.008;
      }
    }

    if (this.x < 0 || this.x > rect.width) this.vx *= -1;
    if (this.y < 0 || this.y > rect.height) this.vy *= -1;
  }

  draw() {
    particleCtx.beginPath();
    particleCtx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    particleCtx.fillStyle = "rgba(210, 250, 255, 0.9)";
    particleCtx.shadowBlur = 8;
    particleCtx.shadowColor = "#63e6ff";
    particleCtx.fill();
    particleCtx.shadowBlur = 0;
  }
}

function initParticles() {
  particles = [];

  for (let i = 0; i < 85; i++) {
    particles.push(new Particle());
  }
}

function connectParticles() {
  for (let a = 0; a < particles.length; a++) {
    for (let b = a + 1; b < particles.length; b++) {
      const dx = particles[a].x - particles[b].x;
      const dy = particles[a].y - particles[b].y;
      const distance = Math.sqrt(dx * dx + dy * dy);

      if (distance < 135) {
        const opacity = 1 - distance / 135;

        particleCtx.strokeStyle = `rgba(99, 230, 255, ${opacity * 0.35})`;
        particleCtx.lineWidth = 0.8;

        particleCtx.beginPath();
        particleCtx.moveTo(particles[a].x, particles[a].y);
        particleCtx.lineTo(particles[b].x, particles[b].y);
        particleCtx.stroke();
      }
    }
  }
}

function animateParticles() {
  const rect = hero.getBoundingClientRect();

  particleCtx.clearRect(0, 0, rect.width, rect.height);

  particles.forEach((particle) => {
    particle.update();
    particle.draw();
  });

  connectParticles();

  requestAnimationFrame(animateParticles);
}

hero.addEventListener("mousemove", (event) => {
  const rect = hero.getBoundingClientRect();

  mouse.x = event.clientX - rect.left;
  mouse.y = event.clientY - rect.top;
});

hero.addEventListener("mouseleave", () => {
  mouse.x = null;
  mouse.y = null;
});

window.addEventListener("resize", () => {
  resizeParticlesCanvas();
  initParticles();
});

resizeParticlesCanvas();
initParticles();
animateParticles();